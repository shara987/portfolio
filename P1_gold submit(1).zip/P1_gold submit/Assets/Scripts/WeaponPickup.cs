using UnityEngine;

public class WeaponPickup : MonoBehaviour
{
    public Weapon weaponToUnlock;
    public AudioClip pickupSound;

    void OnTriggerEnter(Collider other)
    {
        if (!other.transform.root.CompareTag("Player")) return;

        var handler = other.GetComponentInParent<WeaponHandler>();
        if (handler != null && weaponToUnlock != null)
        {
            handler.UnlockSecondary(weaponToUnlock);
            Debug.Log($"Unlocked {weaponToUnlock.weaponName}", this);
        }

        if (pickupSound != null)
            AudioSource.PlayClipAtPoint(pickupSound, Camera.main.transform.position);

        Destroy(gameObject);
    }
}