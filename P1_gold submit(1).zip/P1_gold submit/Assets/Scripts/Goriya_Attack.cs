using System.Collections;
using UnityEngine;

public class Goriya_Attack : MonoBehaviour
{
    public GameObject boomerangPrefab;
    public float throwCooldown = 2f;

    public bool isThrowing { get; private set; }

    private RandomMovementController movement;
    private DirectionalSpriteAnimation spriteAnim;
    private Rigidbody rb;
    private Coroutine attackLoop;
    private GameObject currentBoomerang;

    void Awake()
    {
        movement = GetComponent<RandomMovementController>();
        spriteAnim = GetComponent<DirectionalSpriteAnimation>();
        rb = GetComponent<Rigidbody>();
    }

    void OnEnable()
    {
        attackLoop = StartCoroutine(AttackLoop());
    }

    void OnDisable()
    {
        if (attackLoop != null)
        {
            StopCoroutine(attackLoop);
            attackLoop = null;
        }
        if (currentBoomerang != null)
        {
            Destroy(currentBoomerang);
            currentBoomerang = null;
        }
        isThrowing = false;
    }

    // void Start()
    // {
    //     movement = GetComponent<RandomMovementController>();
    //     spriteAnim = GetComponent<DirectionalSpriteAnimation>();
    //     rb = GetComponent<Rigidbody>();
    //     StartCoroutine(AttackLoop());
    // }

    IEnumerator AttackLoop()
    {
        while (true)
        {
            yield return new WaitForSeconds(throwCooldown);
            yield return StartCoroutine(ThrowBoomerang());
        }
    }

    IEnumerator ThrowBoomerang()
    {
        isThrowing = true;
        movement.enabled = false;
        rb.linearVelocity = Vector3.zero;

        Vector2 direction = DirectionFromLastDirection(spriteAnim.lastDirection);

        currentBoomerang = Instantiate(boomerangPrefab, transform.position, Quaternion.identity);
        Projectile_Enemy boomerang = currentBoomerang.GetComponent<Projectile_Enemy>();
        boomerang.Launch(direction, transform);

        while (!boomerang.hasReturned)
        {
            yield return null;
        }

        Destroy(currentBoomerang);
        currentBoomerang = null;
        movement.enabled = true;
        isThrowing = false;
    }

    Vector2 DirectionFromLastDirection(int dir)
    {
        switch (dir)
        {
            case 0: return Vector2.down;
            case 1: return Vector2.up;
            case 2: return Vector2.right;
            case 3: return Vector2.left;
            default: return Vector2.down;
        }
    }
}
