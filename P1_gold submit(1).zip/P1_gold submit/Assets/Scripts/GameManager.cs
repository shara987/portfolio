using UnityEngine;

public class GameManager : MonoBehaviour
{
    void Awake()
    {
        Screen.SetResolution(1024,960,false);
    }
}
