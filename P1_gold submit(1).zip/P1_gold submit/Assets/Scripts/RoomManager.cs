using UnityEngine;

public class RoomManager : MonoBehaviour
{
    public enum Edge { Top, Bottom, Left, Right }

    [System.Serializable]
    public class EdgeConfig
    {
        public Edge edge;
        public Transform cornerA;
        public Transform cornerB;
        public BladeTrapMovementController trapA;
        public BladeTrapMovementController trapB;

        public Vector3 Midpoint => (cornerA.position + cornerB.position) / 2f;
    }

    public LayerMask playerLayer;
    public EdgeConfig[] edges = new EdgeConfig[4];

    void Update()
    {
        foreach (var edgeConfig in edges)
        {
            bool hit = Physics.Linecast(edgeConfig.cornerA.position, edgeConfig.cornerB.position, playerLayer);

            if (hit)
            {
                // Called every frame the player is on this edge, not just on entry.
                // MoveToMiddle() internally no-ops for a trap that's already busy,
                // so this safely "catches" a trap the instant it becomes free again.
                TryTriggerEdge(edgeConfig);
            }
        }
    }

    void TryTriggerEdge(EdgeConfig edgeConfig)
    {
        if (edgeConfig.trapA.IsAvailable)
        {
            edgeConfig.trapA.MoveToMiddle(edgeConfig.Midpoint);
        }
        if (edgeConfig.trapB.IsAvailable)
        {
            edgeConfig.trapB.MoveToMiddle(edgeConfig.Midpoint);
        }
    }
}