using UnityEngine;

public class StalfosMovement : MonoBehaviour
{
    public float movementSpeedStaflos = 2f;
    public float directionChangeInterval = 6f;
    Rigidbody rb;
    private Vector2 currentDirection;
    private float movementTimer;
    public float gridSize = 1f;
    public float snapTolerance = 0.05f;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        ChooseRandomDirection();
    }

    // Update is called once per frame
    void Update()
    {
        movementTimer += Time.deltaTime;
        if (movementTimer >= directionChangeInterval)
        {
            ChooseRandomDirection();
        }
    }

    void FixedUpdate()
    {
        Vector2 correctedDirection = GetGridBasedMovement(currentDirection);
        rb.linearVelocity = currentDirection * movementSpeedStaflos;
    }
    //void OnCollisionEnter()
   // {
    //    ChooseRandomDirection(); 
   // } 
    void OnCollisionEnter(Collision collision)
    {
        HasHealth health =
        collision.gameObject.GetComponentInParent<HasHealth>();
        if (health != null)
        {

            health.TakeDamage(1, transform.position);
        }
        ChooseRandomDirection();
    }
    void ChooseRandomDirection()
    {
        movementTimer = 0f;
        if(Random.value > 0.5f)
        {
            currentDirection = new Vector2(Random.value > 0.5 ? 1f : -1f, 0f);
        }
        else
        {
            currentDirection = new Vector2(0f,Random.value > 0.5 ? 1f : -1f);
        }
        
    }

    Vector2 GetGridBasedMovement(Vector2 direction)
{
    if (direction == Vector2.zero)
    {
        return Vector2.zero;
    }

    Vector3 position = transform.position;

    if (direction.y != 0)
    {
        float targetX =
            Mathf.Round(position.x / gridSize) * gridSize;

        float differenceX = targetX - position.x;

        if (Mathf.Abs(differenceX) > snapTolerance)
        {
            return new Vector2(
                Mathf.Sign(differenceX),
                0
            );
        }

        Vector3 snappedPosition = transform.position;
        snappedPosition.x = targetX;
        transform.position = snappedPosition;

        return new Vector2(0, direction.y);
    }

    if (direction.x != 0)
    {
        float targetY =
            Mathf.Round(position.y / gridSize) * gridSize;

        float differenceY = targetY - position.y;

        if (Mathf.Abs(differenceY) > snapTolerance)
        {
            return new Vector2(
                0,
                Mathf.Sign(differenceY)
            );
        }

        Vector3 snappedPosition = transform.position;
        snappedPosition.y = targetY;
        transform.position = snappedPosition;

        return new Vector2(direction.x, 0);
    }

    return Vector2.zero;
}
    //to fix:
    //can collide w each other
    //grid movement
    //not get stuck? raycasting, dont pick same direction collided in
    //go diagonal when collide w each other
    //movement needs to closer immitate the game, when they change direction
}
