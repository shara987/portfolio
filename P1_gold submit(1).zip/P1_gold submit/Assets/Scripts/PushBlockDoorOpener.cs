using UnityEngine;

public class PushBlockDoorOpener : MonoBehaviour
{
    public GameObject door;

    private Vector3 startPosition;
    private bool opened = false;

    void Start()
    {
        startPosition = transform.position;
    }

    void Update()
    {
        if (opened)
            return;

        if (transform.position != startPosition)
        {
            OpenDoor();
        }
    }

    void OpenDoor()
    {
        if (door != null)
        {
            door.SetActive(false);
        }

        opened = true;
    }
}