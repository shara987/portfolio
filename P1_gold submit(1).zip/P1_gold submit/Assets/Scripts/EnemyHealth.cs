using System.Collections;
using UnityEngine;
using UnityEngine.UIElements;

public class EnemyHealth : MonoBehaviour
{
    public float maxHealth = 3f;
    private float hp;

    public float invincibilityTime = 0.3f;
    private float lastDamageTime = -999f;

    public float knockbackSpeed = 5f;
    public float hitStunTime = 0.25f;

    private Rigidbody rb;
    private StalfosMovement movement;
    private SpriteRenderer spriteRenderer;
    [SerializeField] private GameObject lootPrefab;

    void Start()
    {
        hp = maxHealth;

        rb = GetComponent<Rigidbody>();
        movement = GetComponent<StalfosMovement>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    public void TakeDamage(float damage, Vector3 attackerPosition)
{
    Debug.Log(
        "TakeDamage called on " + gameObject.name +
        " | time = " + Time.time +
        " | hp before = " + hp
    );

    if (Time.time - lastDamageTime < invincibilityTime)
    {
        Debug.Log("Damage ignored by enemy i-frame");
        return;
    }

    lastDamageTime = Time.time;

    hp -= damage;
    hp = Mathf.Clamp(hp, 0, maxHealth);

    Debug.Log("HP AFTER = " + hp);

    Vector3 knockbackDirection =
        (transform.position - attackerPosition).normalized;

    StartCoroutine(HitStun(knockbackDirection));
    StartCoroutine(Flash());

    if (hp <= 0)
    {
        Die();
    }
}

    IEnumerator HitStun(Vector3 knockbackDirection)
    {
        if (movement != null)
        {
            movement.enabled = false;
        }

        if (rb != null)
        {
            rb.linearVelocity =
                knockbackDirection * knockbackSpeed;
        }

        yield return new WaitForSeconds(hitStunTime);

        if (rb != null)
        {
            rb.linearVelocity = Vector3.zero;
        }

        if (movement != null)
        {
            movement.enabled = true;
        }
    }

    IEnumerator Flash()
    {
        if (spriteRenderer == null)
        {
            yield break;
        }

        for (int i = 0; i < 3; i++)
        {
            spriteRenderer.enabled = false;
            yield return new WaitForSeconds(0.08f);

            spriteRenderer.enabled = true;
            yield return new WaitForSeconds(0.08f);
        }
    }

    void Die()
    {
        Destroy(gameObject);
        Vector2 dropPosition = gameObject.transform.position;
        Instantiate(lootPrefab, dropPosition, Quaternion.identity);

    }
}