using UnityEngine;
using UnityEngine.SceneManagement;

public class CustomGameManager : MonoBehaviour
{
    static public Vector3 checkpointCam = new Vector3(-33.5f,-29f,-10f);
    static public Vector3 playerStartPosition = new Vector3(-33.5f,-33.5f,0);
    public ArrowKeyMovement player;
    public HasInventory playerInv;
    public HasHealth playerHealth;
    public bool customLevelPlaying = false;
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            if (!customLevelPlaying)
            {
                customLevelPlaying = true;
                SetCheckpoint();
            }
            else
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            }   
        }
    }

    public void SetCheckpoint()
    {
        Camera.main.transform.position = checkpointCam;
        player.transform.position = playerStartPosition;
        playerHealth.hp = 6;
        playerInv.rupees = 0;
        playerInv.bombs = 0;
        playerInv.keys = 0;
    }


}