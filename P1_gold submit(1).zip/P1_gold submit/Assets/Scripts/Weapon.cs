using UnityEngine;

public enum AmmoType { None, Rupee, Bomb }

public abstract class Weapon : MonoBehaviour
{
    public static readonly Vector2[] Dirs = { Vector2.down, Vector2.up, Vector2.right, Vector2.left };

    public string weaponName;

    public abstract void Use(int direction);
    public abstract Sprite GetIconSprite();

    public virtual void SwappedIn() { }
    public virtual void SwappedOut() { }
}