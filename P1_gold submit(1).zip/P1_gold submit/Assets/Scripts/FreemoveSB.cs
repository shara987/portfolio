using UnityEngine;

public class FreemoveSB : MonoBehaviour
{
    public float moveSpeed = 3f;

    private void OnTriggerStay(Collider other)
    {
        if (!other.CompareTag("Player"))
            return;

        Rigidbody rb =
            other.GetComponent<Rigidbody>();

        if (rb == null)
            return;

        float horizontal =
            Input.GetAxisRaw("Horizontal");

        float vertical =
            Input.GetAxisRaw("Vertical");

        Vector3 velocity = rb.linearVelocity;

        velocity.x = horizontal * moveSpeed;
        velocity.y = vertical * moveSpeed;

        rb.linearVelocity = velocity;
    }
}