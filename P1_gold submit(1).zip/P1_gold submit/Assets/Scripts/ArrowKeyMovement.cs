using UnityEngine;

public class ArrowKeyMovement : MonoBehaviour
{
    public float movement_speed = 4f;
    GridBasedMovement grid;
    public bool isDoorCollision = false;
    //0 = down
    // 1 = up
    // 2 = right
    // 3 = left
    public int doorDirection = -1;
    public float raySize = 0.55f;
    public HasInventory inventory;
    public float doorCooldown = 0.5f;
    public Sword sword;
    private float lastTransitionTime = -999f;
    static public bool isCracked = false;
    static public float crackedSpeed = 6f;
    static public float timerSinceCracked = 0;
    public float maxCrackedTime = 12f;
    
    Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        grid = GetComponent<GridBasedMovement>();
    }

    void Update()
    {
        if (isCracked)
        {
            timerSinceCracked += Time.deltaTime;
        }
        if(timerSinceCracked >= maxCrackedTime)
        {
            isCracked = false;
            timerSinceCracked = 0f;
        }
        if (sword != null && sword.isSwinging)
        {
            rb.linearVelocity = Vector2.zero;
            return;
        }
        Vector2 current_input = GetInput();
        Vector2 corrected_input;
        if (!isCracked)
        {
            corrected_input = grid.GridSnapping(current_input,movement_speed);
        }
        else
        {
            corrected_input = grid.GridSnapping(current_input,crackedSpeed);
        }
        if (isCracked)
        {
            rb.linearVelocity = corrected_input * crackedSpeed;
        }
        else
        {
            rb.linearVelocity = corrected_input * movement_speed;
        }
    }

    Vector2 GetInput()
    {
        float horizontal_input = Input.GetAxisRaw("Horizontal");
        float vertical_input = Input.GetAxisRaw("Vertical");
        if (Mathf.Abs(horizontal_input) > 0.0f)
        {
            vertical_input = 0.0f;
        }
        return new Vector2 (horizontal_input, vertical_input);
    }

    //trasition logic
    // void OnTriggerEnter(Collider other)
    // {
    //     if(other.gameObject.CompareTag("door"))
    //     {
    //         isDoorCollision = true;
    //         doorDirection = GetDirectionFromPositions(other);
    //         Debug.Log("Door direction detected: " + doorDirection);
    //         //doorDirection = raycastResult();
    //     }
    // }

    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("door")) return;
        if (Time.time - lastTransitionTime < doorCooldown) return;

        var doorComp = other.GetComponentInParent<Door>();
        if (doorComp == null)
        {
            Debug.LogError($"'{other.name}' is tagged door but has NO Door component!", other);
            return;
        }
        if (doorComp.isLocked)
        {
            Debug.Log($"Door '{other.name}' is locked", other);
            return;
        }

        Vector2 v = rb.linearVelocity;

        if (doorComp.axis == Door.Axis.Vertical)
        {
            if (Mathf.Abs(v.y) < 0.01f) return;   // not moving through this axis
            doorDirection = v.y > 0 ? 1 : 0;      // 1 = up, 0 = down
        }
        else
        {
            if (Mathf.Abs(v.x) < 0.01f) return;
            doorDirection = v.x > 0 ? 2 : 3;      // 2 = right, 3 = left
        }

        isDoorCollision = true;
        lastTransitionTime = Time.time;
        Debug.Log($"Door '{other.name}' axis={doorComp.axis} → direction {doorDirection}", other);
    }

    int GetDirectionFromPositions(Collider door)
    {
        Vector3 diff = transform.position - door.bounds.center;

        if (Mathf.Abs(diff.y) > Mathf.Abs(diff.x))
        {
            return diff.y < 0 ? 1 : 0;
        }
        else
        {
            return diff.x < 0 ? 2 : 3;
        }
    }

    //inventory logic
    void OnCollisionEnter(Collision collision)
    {

        if (collision.gameObject.CompareTag("locked"))
        {
            if(inventory.GetKeys() > 0)
            {
                Destroy(collision.gameObject);
                inventory.keys--;
            }
        }
        if(collision.gameObject.CompareTag("BreakBlock") && isCracked)
        {
            Destroy(collision.gameObject, 0.04f);
        }
    }
}