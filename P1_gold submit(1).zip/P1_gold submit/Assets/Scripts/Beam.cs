using UnityEngine;

public class Beam : MonoBehaviour
{
    public float speed = 10f;
    public int damage = 1;

    [Header("Optional (leave off for a plain arrow/beam)")]
    public float maxDistance = 0f;       // 0 = unlimited
    public bool returnToOwner = false;   // boomerang

    [HideInInspector] public Transform owner;

    public System.Action onDestroyed;

    public Sprite[] directionSprites;    // down, up, right, left (leave empty for boomerang)

    [Header("Boomerang")]
    public bool stunOnly = false;
    public float stunDuration = 2f;
    public bool spins = false;
    private float spinSpeed = 720f;
    private float returnTimer = 0f;
    private Vector2 moveDirection;
    private SpriteRenderer spriteRenderer;
    private float distanceTraveled = 0f;
    private bool returning = false;
    private Rigidbody rb;

    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody>();
        rb.isKinematic = false;
        rb.useGravity  = false;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        rb.constraints = RigidbodyConstraints.FreezePositionZ;
    }

    public void SetDirectionFromInt(int direction)
    {
        moveDirection = Weapon.Dirs[direction];
        if (directionSprites != null && directionSprites.Length == 4)
            spriteRenderer.sprite = directionSprites[direction];
    }

    void OnDestroy()
    {
        onDestroyed?.Invoke();
    }

    public void SetDirection(Vector2 direction)
    {
        moveDirection = direction.normalized;
    }

    void Update()
    {
        if (spins)
        {
                transform.Rotate(Vector3.forward * spinSpeed * Time.deltaTime);
        }
        if (returning)
        {
            if (owner == null) { Destroy(gameObject); return; }

            Vector3 toOwner = owner.position - transform.position;
            if (toOwner.magnitude < 0.5f) { Destroy(gameObject); return; }

            rb.linearVelocity = (Vector2)toOwner.normalized * speed;   // was transform.position +=
            return;
        }

        rb.linearVelocity = moveDirection * speed;
        distanceTraveled += speed * Time.deltaTime;
        if (maxDistance > 0f && distanceTraveled >= maxDistance) EndOfTravel();
    }

    private void EndOfTravel()
    {
        Debug.Log($"EndOfTravel: returnToOwner={returnToOwner}, owner={(owner == null ? "NULL" : owner.name)}", this);
        if (returnToOwner) returning = true;
        else Destroy(gameObject);
    }

    private void OnCollisionEnter(Collision collision)
    {
        Debug.Log("!!!!!!!! BEAM COLLISION !!!!!!!!");
        GameObject other = collision.gameObject;
        Debug.Log("Beam collided with: " + other.name + " tag=" + other.tag);
        if (owner != null && other.transform.IsChildOf(owner)) 
        {
            return; 
        }
        if (returning)
        {
            //ignores physics on walls (so doesn't get stuck on walls)
            if (other.CompareTag("wall") || other.CompareTag("locked"))
            {
                Physics.IgnoreCollision(GetComponent<Collider>(), collision.collider, true);
            }
        }
        if (other.CompareTag("enemy"))
        {
            if (stunOnly)
            {
                EnemyStunHandler stun = other.GetComponentInParent<EnemyStunHandler>();
                if (stun != null)
                {
                    stun.ApplyKnockback(Vector2.zero, stunDuration);
                }
            }
            else
            {
                HasHp enemyHealth = other.GetComponentInParent<HasHp>();
                if (enemyHealth != null) enemyHealth.TakeDamage(damage, transform.position);
            }
            EndOfTravel();
        }
        else if (other.CompareTag("wall") || other.CompareTag("locked"))
        {
            EndOfTravel();
        }
        else if (other.CompareTag("Player") && !ArrowKeyMovement.isCracked)
        {
            HasHealth playerHealth = other.GetComponentInParent<HasHealth>();
            if (playerHealth != null)
                playerHealth.TakeDamage(damage, transform.position);
            EndOfTravel();
        }
    }

    //stops them from killing themselves
    public void IgnoreOwnerCollisions()
    {
        if (owner == null) return;

        Collider myCol = GetComponent<Collider>();
        if (myCol == null) return;

        foreach (Collider ownerCol in owner.GetComponentsInChildren<Collider>())
            Physics.IgnoreCollision(myCol, ownerCol, true);
    }
}