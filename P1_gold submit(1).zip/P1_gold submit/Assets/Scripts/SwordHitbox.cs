using UnityEngine;

public class SwordHitbox : MonoBehaviour
{
    public float dealDamage = 1f;

    void OnTriggerEnter(Collider other)
    {
        // Ignore anything belonging to whoever swings this sword.
        if (other.transform.root == transform.root) return;

        if (other.CompareTag("enemy"))
        {
            HasHp hp = other.GetComponentInParent<HasHp>();
            if (hp != null) hp.TakeDamage(dealDamage, transform.position);
        }
    }
}
