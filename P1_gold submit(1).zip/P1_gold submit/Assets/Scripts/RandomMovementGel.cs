using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomMovementGel : MonoBehaviour
{
    public float movementSpeed = 2f;
    public int tilesPerDirection = 2;
    //public float distanceBfrSwitch = 2f;
    public float gelPauseDuration = 1f;
    Rigidbody rb;

    GridBasedMovement grid;
    Collider col;

	//Vector2[] directions = { Vector2.up, Vector2.right, Vector2.down, Vector2.left };
    static readonly Vector2[] directions = { Vector2.up, Vector2.right, Vector2.down, Vector2.left };
    readonly List<Vector2> open = new List<Vector2>();
    public LayerMask obstacleMask;

	Coroutine currentMove;

	// Use this for initialization
    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        grid = GetComponent<GridBasedMovement>();
        col = GetComponent<Collider>();
    }

	// void Start () {
	// 	rb = GetComponent<Rigidbody>();
    //     grid = GetComponent<GridBasedMovement>();
	// 	currentMove = StartCoroutine(Move());
	// }
	void OnEnable()
    {
        // (Re)start movement whenever this script becomes enabled
        // if (rb != null) // guards against OnEnable firing before Start on initial load
        // {
        //     rb.linearVelocity = Vector3.zero;
        // }
        currentMove = StartCoroutine(Move());
    }
    void OnDisable()
    {
        // Stop movement immediately when disabled — this is the missing piece
        if (currentMove != null)
        {
            StopCoroutine(currentMove);
            currentMove = null;
        }
        if (rb != null)
        {
            rb.linearVelocity = Vector3.zero;
        }
    }

    // IEnumerator Move()
    // {
    //     while (true) {
	// 		Vector2 dir = directions[Random.Range(0, directions.Length)];
	// 		 float traveledSinceLastPause = 0f;
    //         float pauseEveryDistance = grid.grid_size; // one tile

    //         for (float moved = 0; moved < distanceBfrSwitch; moved += movementSpeed * Time.deltaTime)
    //         {
    //             Vector2 snapped_dir = grid.GridSnapping(dir);
    //             rb.linearVelocity = snapped_dir * movementSpeed;

    //             traveledSinceLastPause += movementSpeed * Time.deltaTime;

    //             if (traveledSinceLastPause >= pauseEveryDistance)
    //             {
    //                 traveledSinceLastPause = 0f;

    //                 // Stop and rest on this tile
    //                 rb.linearVelocity = Vector2.zero;
    //                 yield return new WaitForSeconds(gelPauseDuration);
    //             }

    //             yield return null;
    //         }
	// 	}
    // }

    IEnumerator Move()
    {
        while (true)
        {
            // If a knockback (or anything else) left us off-grid, glide back to a tile center first
            Vector3 center = NearestTileCenter(rb.position);
            if ((center - rb.position).sqrMagnitude > 0.0001f)
            {
                yield return StartCoroutine(StepTo(center));
            }

            Vector2 dir = PickOpenDirection();
            if (dir == Vector2.zero)
            {
                yield return new WaitForSeconds(0.2f); // boxed in, look again shortly
                continue;
            }

            for (int i = 0; i < tilesPerDirection; i++)
            {
                Vector3 here = NearestTileCenter(rb.position);
                Vector3 target = here + (Vector3)(dir * grid.grid_size);

                if (IsBlocked(target)) break; // wall ahead: stop and pick a new direction

                yield return StartCoroutine(StepTo(target));
                yield return new WaitForSeconds(gelPauseDuration); // rest on the tile
            }
        }
    }

    IEnumerator StepTo(Vector3 target)
    {
        Vector3 start = NearestTileCenter(rb.position);
        target.z = rb.position.z;
        float stuckTime = 0f;

        while (true)
        {
            Vector3 toTarget = target - rb.position;
            toTarget.z = 0f;
            float dist = toTarget.magnitude;
            if (dist <= 0.001f) break;

            // never move farther than what's left, so we land exactly on the target
            float speed = Mathf.Min(movementSpeed, dist / Time.fixedDeltaTime);
            rb.linearVelocity = toTarget.normalized * speed;

            Vector3 before = rb.position;
            yield return new WaitForFixedUpdate();

            // something (player, another enemy) blocked us mid-step: pop back to the tile we left
            if ((rb.position - before).sqrMagnitude < 0.000001f)
            {
                stuckTime += Time.fixedDeltaTime;
                if (stuckTime > 0.3f)
                {
                    target = start;
                    rb.linearVelocity = Vector3.zero;
                    rb.position = start;
                    yield break;
                }
            }
            else
            {
                stuckTime = 0f;
            }
        }

        rb.linearVelocity = Vector3.zero;
        rb.position = target; // exact landing, no decimals
    }

    Vector2 PickOpenDirection()
    {
        open.Clear();
        Vector3 here = NearestTileCenter(rb.position);
        foreach (Vector2 d in directions)
        {
            if (!IsBlocked(here + (Vector3)(d * grid.grid_size))) open.Add(d);
        }
        return open.Count == 0 ? Vector2.zero : open[Random.Range(0, open.Count)];
    }

    bool IsBlocked(Vector3 tileCenter)
    {
        Bounds b = col.bounds;
        Vector3 offset = b.center - transform.position; // account for an offset collider
        return Physics.CheckBox(tileCenter + offset, b.extents * 0.9f, Quaternion.identity,
                                obstacleMask, QueryTriggerInteraction.Ignore);
    }

    Vector3 NearestTileCenter(Vector3 p)
    {
        float g = grid.grid_size;
        return new Vector3(Mathf.Round(p.x / g) * g, Mathf.Round(p.y / g) * g, p.z);
    }

	// void OnCollisionStay() {
    //     if (!enabled) return;
    //     if (currentMove != null)
    //     {
    //         StopCoroutine(currentMove);
    //     }
	// 	currentMove = StartCoroutine(Move());
	// }
}
