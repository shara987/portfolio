using UnityEngine;

public class Water_LavaBlock : MonoBehaviour
{

    public HasHealth playerHealth;
    public float crackederSpeed = 10f;
    private float tempOldCrackedSpeed = ArrowKeyMovement.crackedSpeed;

    void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Player") && ArrowKeyMovement.isCracked)
        {
            //faster
            ArrowKeyMovement.crackedSpeed = crackederSpeed;
        }
        else if(other.CompareTag("Player") && !ArrowKeyMovement.isCracked)
        {
            playerHealth.Die();
        }
    }

    void OnTriggerExit(Collider other)
    {
       if (other.CompareTag("Player") && ArrowKeyMovement.isCracked)
        {
            //slower
            ArrowKeyMovement.crackedSpeed = tempOldCrackedSpeed;
        }
    }
}
