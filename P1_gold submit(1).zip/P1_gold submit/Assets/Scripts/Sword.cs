using UnityEngine;
using System.Collections;

public class Sword : Weapon
{
    public GameObject swordHitboxObject;
    public SpriteRenderer swordSpriteRenderer;
    public Sprite swordUp;
    public Sprite swordDown;
    public Sprite swordLeft;
    public Sprite swordRight;

    public GameObject beamPrefab;
    public AudioClip swordSound;

    public float swingDuration = 0.3f;

    public bool isSwinging = false;
    // to stop link from moving while swinging
    private GameObject currBeam;

    void Awake()
    {
        if (swordHitboxObject != null)
            swordHitboxObject.SetActive(false);   // never live unless swinging
    }

    public override void Use(int direction)
    {
        if (isSwinging)
        {
            return;
        }

        if (swordSound != null)
        {
            AudioSource.PlayClipAtPoint(swordSound,transform.position);
        }
        StartCoroutine(SwingRoutine(direction));
    }

    private void SetSpriteDirection(int direction)
    {
        switch (direction)
        {
            case 0:
                swordSpriteRenderer.sprite = swordDown;
                break;
            case 1:
                swordSpriteRenderer.sprite = swordUp;
                break;
            case 2:
                swordSpriteRenderer.sprite = swordRight;
                break;
            case 3:
                swordSpriteRenderer.sprite = swordLeft;
                break;
        }
    }

    private IEnumerator SwingRoutine(int direction)
    {
        isSwinging = true;
        SetSpriteDirection(direction);

        Vector3 originalPosition = swordHitboxObject.transform.localPosition;
        Vector3 swingDirection = Vector3.zero;

        switch (direction)
        {
            case 0:
                swingDirection = Vector3.down;
                break;
            case 1:
                swingDirection = Vector3.up;
                break;
            case 2:
                swingDirection = Vector3.right;
                break;
            case 3:
                swingDirection = Vector3.left;
                break;
        }

        swordHitboxObject.SetActive(true);

        swordHitboxObject.transform.localPosition = originalPosition + swingDirection * 1f;
        yield return new WaitForSeconds(swingDuration);
        HasHealth health = GetComponentInParent<HasHealth>();
        if (health != null && health.GetHealth() >= health.maxHealth)
        {
            FireBeam(direction);
        }
        swordHitboxObject.SetActive(false);

        swordHitboxObject.transform.localPosition = originalPosition;

        isSwinging = false;
    }

    private void FireBeam(int direction)
    {
        if (beamPrefab == null || currBeam != null)
        {
            return;
        }
        Vector3 spawnPos = transform.position + (Vector3)(Weapon.Dirs[direction] * 1f);
        currBeam = Instantiate(beamPrefab, spawnPos, Quaternion.identity);
        Beam beam = currBeam.GetComponent<Beam>();
        beam.owner = transform.root;
        beam.SetDirectionFromInt(direction);
        beam.IgnoreOwnerCollisions();
    }

    public override Sprite GetIconSprite()
    {
        return swordUp;
    }
}