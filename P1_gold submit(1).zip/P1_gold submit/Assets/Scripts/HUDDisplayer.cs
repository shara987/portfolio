using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class HUDDisplayer : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public HasInventory inventory;
    public enum StatType { Rupees, Bombs, Keys}

    public StatType statShow;
    TMP_Text text_component;
    void Start()
    {
        text_component = GetComponentInChildren<TMP_Text>();

    }

    // Update is called once per frame
    void Update()
    {
        if(inventory != null && text_component != null)
        {
            switch (statShow)
            {
                case StatType.Rupees:
                    text_component.text = inventory.GetRupees().ToString();
                    break;
                case StatType.Bombs:
                    text_component.text = inventory.GetBombs().ToString();
                    break;
                case StatType.Keys:
                    text_component.text = inventory.GetKeys().ToString();
                    break;
            }
        }
    }
}
