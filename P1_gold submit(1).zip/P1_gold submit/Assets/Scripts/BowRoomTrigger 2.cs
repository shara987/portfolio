// using UnityEngine;

// public class BowRoomTrigger : MonoBehaviour
// {
//     public Transform bowRoomSpawn;
//     public Transform bowRoomCameraTarget;
//     public Camera mainCamera;

//     private void OnTriggerEnter(Collider other)
//     {
//         if (!other.CompareTag("Player"))
//         {
//             return;
//         }

//         ArrowKeyMovement topDownMovement =
//             other.GetComponent<ArrowKeyMovement>();

//         SideScrollMovement sideMovement =
//             other.GetComponent<SideScrollMovement>();

//         Rigidbody rb =
//             other.GetComponent<Rigidbody>();

//         if (topDownMovement != null)
//         {
//             topDownMovement.enabled = false;
//         }

//         if (sideMovement != null)
//         {
//             sideMovement.enabled = true;
//         }

//         if (rb != null)
//         {
//             rb.linearVelocity = Vector3.zero;
//             rb.useGravity = true;
//         }

//         if (bowRoomSpawn != null)
//         {
//             other.transform.position = bowRoomSpawn.position;
//         }

//         if (mainCamera != null && bowRoomCameraTarget != null)
//         {
//             mainCamera.transform.position =
//                 bowRoomCameraTarget.position;
//         }
//     }
// }