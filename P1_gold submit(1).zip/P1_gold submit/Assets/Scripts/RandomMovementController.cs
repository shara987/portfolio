using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomMovementController : MonoBehaviour
{
    public float movementSpeed = 2f;
    public float distanceBfrSwitch = 2f;
    Rigidbody rb;

    GridBasedMovement grid;

	Vector2[] directions = { Vector2.up, Vector2.right, Vector2.down, Vector2.left };
    //public LayerMask obstacleMask;        // put walls/blocks on a layer and select it here
    //public float probeDistance = 0.6f;
    //Collider col;
    //static readonly Vector2[] directions = { Vector2.up, Vector2.right, Vector2.down, Vector2.left };
    //readonly List<Vector2> open = new List<Vector2>();

	Coroutine currentMove;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        grid = GetComponent<GridBasedMovement>();
        //col = GetComponent<Collider>();
    }

	// Use this for initialization
	// void Start () {
	// 	rb = GetComponent<Rigidbody>();
    //     grid = GetComponent<GridBasedMovement>();
	// 	currentMove = StartCoroutine(Move());
	// }
	void OnEnable()
    {
        // (Re)start movement whenever this script becomes enabled
        // if (rb != null) // guards against OnEnable firing before Start on initial load
        // {
        //     rb.linearVelocity = Vector3.zero;
        // }
        currentMove = StartCoroutine(Move());
    }
    void OnDisable()
    {
        // Stop movement immediately when disabled — this is the missing piece
        if (currentMove != null)
        {
            StopCoroutine(currentMove);
            currentMove = null;
        }
        if (rb != null)
        {
            rb.linearVelocity = Vector3.zero;
        }
    }

    IEnumerator Move()
    {
        while (true) {
			Vector2 dir = directions[Random.Range(0, directions.Length)];
			for (float moved = 0; moved < distanceBfrSwitch; moved += movementSpeed * Time.deltaTime) {
                Vector2 snapped_dir = grid.GridSnapping(dir);
				rb.linearVelocity = snapped_dir * movementSpeed;
				yield return null;
			}
		}
    }

	void OnCollisionStay() {
        if (!enabled) return;
		 if (currentMove != null)
        {
            StopCoroutine(currentMove);
        }
		currentMove = StartCoroutine(Move());
	}
    // IEnumerator Move()
    // {
    //     while (true)
    //     {
    //         Vector2 dir = PickOpenDirection();

    //         if (dir == Vector2.zero)
    //         {
    //             // boxed in on all four sides: wait briefly and look again
    //             rb.linearVelocity = Vector3.zero;
    //             yield return new WaitForSeconds(0.2f);
    //             continue;
    //         }

    //         for (float moved = 0; moved < distanceBfrSwitch; moved += movementSpeed * Time.deltaTime)
    //         {
    //             if (IsBlocked(dir)) break; // wall ahead: stop and pick a new direction

    //             Vector2 snapped = grid.GridSnapping(dir);
    //             rb.linearVelocity = snapped * movementSpeed;
    //             yield return null;
    //         }
    //     }
    // }

    // Vector2 PickOpenDirection()
    // {
    //     open.Clear();
    //     foreach (Vector2 d in directions)
    //     {
    //         if (!IsBlocked(d)) open.Add(d);
    //     }
    //     return open.Count == 0 ? Vector2.zero : open[Random.Range(0, open.Count)];
    // }

    // bool IsBlocked(Vector2 dir)
    // {
    //     Bounds b = col.bounds;
    //     Vector3 halfExtents = b.extents * 0.9f; // slightly smaller so side walls don't register
    //     return Physics.BoxCast(b.center, halfExtents, dir, Quaternion.identity,
    //                            probeDistance, obstacleMask, QueryTriggerInteraction.Ignore);
    // }

    // void OnCollisionStay()
    // {
    //     if (!enabled) return; // physics messages still arrive while disabled
    //     if (currentMove != null) StopCoroutine(currentMove);
    //     currentMove = StartCoroutine(Move());
    // }
}
