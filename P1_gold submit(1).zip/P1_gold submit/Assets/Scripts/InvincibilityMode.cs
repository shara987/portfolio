using System.Collections;
using UnityEngine;

public class InvincibilityMode : MonoBehaviour
{
    public bool wasHit;
    public float invincibilityLength = 3f;
    public bool isInvincible { get; private set; }
    private Coroutine timedInvincibilityCoroutine;
    bool inDoorway = false;
    void Update()
    {
        if (wasHit)
        {
            //call function that disables dealing damage and health for invincibilityLength
            wasHit = false;
            StartTimedInvincibility(invincibilityLength);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("door"))
        {
            //call function that disables dealing damage and health
            inDoorway = true;
            isInvincible = true;
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("door"))
        {
            inDoorway = false;
            if(timedInvincibilityCoroutine == null)
            {
                isInvincible = false;
            }
        }
    }


    void StartTimedInvincibility(float length)
    {
        if(timedInvincibilityCoroutine != null)
        {
            StopCoroutine(timedInvincibilityCoroutine);
        }
        timedInvincibilityCoroutine = StartCoroutine(Invincibility(length));
    }

    IEnumerator Invincibility(float length)
    {
        isInvincible = true;
        yield return new WaitForSeconds(length);
        timedInvincibilityCoroutine = null;

        // Don't turn it off if still standing in a doorway
        if (!inDoorway)
        {
            isInvincible = false;
        }
    }
}
