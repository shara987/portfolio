using UnityEngine;
using UnityEngine.UI;

public class WeaponSlot : MonoBehaviour
{
    public WeaponHandler weaponHandler;
    private Image slotImage;
    public bool isSlotA = true;

    void Start()
    {
        slotImage = GetComponent<Image>();
    }

    void Update()
    {
        if (weaponHandler == null || slotImage == null)
        {
            return;
        }
        Weapon curr = isSlotA ? weaponHandler.primaryWeapon : weaponHandler.CurrentSecondary;

        if (curr != null)
        {
            slotImage.sprite = curr.GetIconSprite();
            slotImage.enabled = true;
        }
        else
        {
            slotImage.enabled = false;
        }
    }
}