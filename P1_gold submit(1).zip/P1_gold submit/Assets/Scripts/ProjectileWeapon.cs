using UnityEngine;

public class ProjectileWeapon : Weapon
{
    public GameObject prefab;
    public Sprite icon;
    public AmmoType ammo = AmmoType.None;
    public bool onlyOneAtATime = false;   // true for boomerang
    public float spawnDistance = 1f;

    public SpriteRenderer linkSpriteRenderer;
    public Sprite[] linkSprites;          // down, up, right, left

    private GameObject active;

    public override void Use(int direction)
    {
        if (prefab == null) { Debug.Log($"{weaponName}: no prefab"); return; }
        if (onlyOneAtATime && active != null) { Debug.Log($"{weaponName}: one at a time"); return; }

        if (ammo != AmmoType.None)
        {
            HasInventory inv = GetComponentInParent<HasInventory>();
            if (inv == null) { Debug.Log($"{weaponName}: no inventory"); return; }
            if (!inv.TrySpend(ammo)) { Debug.Log($"{weaponName}: out of {ammo}"); return; }
        }

        if (linkSpriteRenderer != null && linkSprites != null && linkSprites.Length == 4)
            linkSpriteRenderer.sprite = linkSprites[direction];

        Vector3 spawnPos = transform.position + (Vector3)(Dirs[direction] * spawnDistance);
        active = Instantiate(prefab, spawnPos, Quaternion.identity);

        Beam beam = active.GetComponent<Beam>();   // bomb prefabs won't have one
        if (beam != null)
        {
            beam.owner = transform.root;
            beam.SetDirectionFromInt(direction);
            beam.onDestroyed = () => active = null;
            beam.IgnoreOwnerCollisions();
        }
    }

    public override Sprite GetIconSprite() { return icon; }
}