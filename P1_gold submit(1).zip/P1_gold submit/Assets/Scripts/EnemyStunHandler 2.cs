// using System.Collections;
// using UnityEngine;

// public class EnemyStunHandler : MonoBehaviour
// {
//     public float flashTransition = 0.08f;
//     public float flashDuration = 3f;
//     public float invincibilityAfterStun = 0.3f; 
//     private RandomMovementController movement1;
//     private RandomDiagonalMovement movement2;
//     private RandomMovementGel movement3;
//     private Rigidbody rb;
//     SpriteRenderer sprite;
//     public bool isStunned { get; private set; } // other scripts can check this
//     public bool isInvincible { get; private set; }
//     public bool isWallmaster = false;

//     void Awake()
//     {

//         movement1 = GetComponent<RandomMovementController>();
//         movement2 = GetComponent<RandomDiagonalMovement>();
//         movement3 = GetComponent<RandomMovementGel>();

//         rb = GetComponent<Rigidbody>();
//         sprite = GetComponent<SpriteRenderer>();
//     }

//     public void ApplyKnockback(Vector2 force, float duration)
//     {
//         StopAllCoroutines();
//         if (sprite != null) sprite.enabled = true;
//         if (movement1 != null)
//         {
//             movement1.enabled = true;
            
//         } 
//          else if (movement2 != null)
//         {
//             movement2.enabled = true;
            
//         }
//          else if (movement3 != null)
//         {
//             movement3.enabled = true;
            
//         }
//         isStunned = false;
//         isInvincible = false;

//         if (!isWallmaster) StartCoroutine(KnockbackStun(force, duration));
//         StartCoroutine(Flash());
//     }


//     IEnumerator KnockbackStun(Vector2 force, float duration)
//     {
//         isStunned = true;
//         isInvincible = true;

//         if (movement1 != null)
//         {
//             movement1.enabled = false;
            
//         } 
//          else if (movement2 != null)
//         {
//             movement2.enabled = false;
            
//         }
//          else if (movement3 != null)
//         {
//             movement3.enabled = false;
            
//         }
//         rb.linearVelocity = force;

//         yield return new WaitForSeconds(duration);

//         rb.linearVelocity = Vector2.zero;
//         if (movement1 != null)
//         {
//             movement1.enabled = true;
            
//         } 
//          else if (movement2 != null)
//         {
//             movement2.enabled = true;
            
//         }
//          else if (movement3 != null)
//         {
//             movement3.enabled = true;
            
//         }
//         isStunned = false;

//         yield return new WaitForSeconds(invincibilityAfterStun);

//         isInvincible = false;
//     }

//     IEnumerator Flash()
//     {
//         if (sprite == null) yield break;
//         try
//         {
//             for (int i = 0; i < flashDuration; i++)
//             {
//                 sprite.enabled = false;
//                 yield return new WaitForSeconds(flashTransition);
//                 sprite.enabled = true;
//                 yield return new WaitForSeconds(flashTransition);
//             }
//         }
//         finally
//         {
//             sprite.enabled = true;   // runs even when StopAllCoroutines kills us
//         }
//     }
// }
