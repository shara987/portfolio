using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Bomb : MonoBehaviour
{
    public float fuseTime = 1.5f;
    public float radius = 2f;
    public int damage = 4;
    public GameObject blastEffectPrefab;
    public float effectDuration = 0.4f;
    public GameObject blastObject;
    public SpriteRenderer bombSprite;

    IEnumerator Start()
    {
        yield return new WaitForSeconds(fuseTime);
        Explode();
    }

    void Explode()
    {
        HashSet<HasHp> hit = new HashSet<HasHp>();

        foreach (GameObject e in GameObject.FindGameObjectsWithTag("enemy"))
        {
            if (Vector3.Distance(transform.position, e.transform.position) > radius) continue;

            HasHp health = e.GetComponentInParent<HasHp>();
            if (health != null && hit.Add(health))
            {
                health.TakeDamage(damage, transform.position);
            }
        }


        if (bombSprite != null)
        {
            bombSprite.enabled = false;
        }
        if (blastObject != null)
        {
            blastObject.SetActive(true);
        }
        Destroy(gameObject, effectDuration);
    }
}