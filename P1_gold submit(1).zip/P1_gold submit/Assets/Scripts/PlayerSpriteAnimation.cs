using UnityEngine;

public class PlayerSpriteAnimation : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public Sprite down1;
    public Sprite down2;

    public Sprite up1;
    public Sprite up2;

    public Sprite right1;
    public Sprite right2;

    public Sprite left1;
    public Sprite left2;

    public float animationSpeed = 0.15f;

    private SpriteRenderer spriteRenderer;
    private Rigidbody rb;
    private HasHealth health;

    private float timer = 0f;
    private bool secondFrame = false;

    // 0 = down
    // 1 = up
    // 2 = right
    // 3 = left
    private int lastDirection = 0;

    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody>();
        health = GetComponent<HasHealth>();
    }

    // Update is called once per frame
    void Update()
    {
        
        if(health != null && health.isHitStunned)
        {
            return;
        }
        Vector3 velocity = rb.linearVelocity;

        bool isMoving =
            Mathf.Abs(velocity.x) > 0.01f ||
            Mathf.Abs(velocity.y) > 0.01f;

        if (!isMoving)
        {
            timer = 0f;
            secondFrame = false;

            ShowIdleSprite();
            return;
        }

        timer += Time.deltaTime;

        if (timer >= animationSpeed)
        {
            timer = 0f;
            secondFrame = !secondFrame;
        }

        if (velocity.x > 0.01f)
        {
            lastDirection = 2;
            spriteRenderer.sprite =
                secondFrame ? right2 : right1;
        }

        else if (velocity.x < -0.01f)
        {
            lastDirection = 3;
            spriteRenderer.sprite =
                secondFrame ? left2 : left1;
        }

        else if (velocity.y > 0.01f)
        {
            lastDirection = 1;
            spriteRenderer.sprite =
                secondFrame ? up2 : up1;
        }

        else if (velocity.y < -0.01f)
        {
            lastDirection = 0;
            spriteRenderer.sprite =
                secondFrame ? down2 : down1;
        }
    }

    void ShowIdleSprite()
    {
        if (lastDirection == 0)
        {
            spriteRenderer.sprite = down1;
        }
        else if (lastDirection == 1)
        {
            spriteRenderer.sprite = up1;
        }
        else if (lastDirection == 2)
        {
            spriteRenderer.sprite = right1;
        }
        else if (lastDirection == 3)
        {
            spriteRenderer.sprite = left1;
        }
    }

    public int GetLastDirection()
    {
        return lastDirection;
    }
}