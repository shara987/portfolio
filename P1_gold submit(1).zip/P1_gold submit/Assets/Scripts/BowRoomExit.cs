using UnityEngine;

public class BowRoomExit : MonoBehaviour
{
    public Transform dungeonReturnPoint;
    public Transform dungeonCameraTarget;
    public Camera mainCamera;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player"))
            return;

        ArrowKeyMovement topDown =
            other.GetComponent<ArrowKeyMovement>();

        SideScrollMovement side =
            other.GetComponent<SideScrollMovement>();

        Rigidbody rb =
            other.GetComponent<Rigidbody>();

        if (side != null)
        {
            side.enabled = false;
        }

        if (topDown != null)
        {
            topDown.enabled = true;
        }

        // 先传送
        if (dungeonReturnPoint != null)
        {
            other.transform.position =
                dungeonReturnPoint.position;
            //move camera back
        }

        // 出 Bow Room 后彻底清掉侧视状态
        if (rb != null)
        {
            rb.linearVelocity = Vector3.zero;
            rb.useGravity = false;  // 退出 Bow Room：关 gravity
        }

        if (mainCamera != null &&
            dungeonCameraTarget != null)
        {
            mainCamera.transform.position =
                dungeonCameraTarget.position;
        }

        Debug.Log("EXIT: gravity = " + rb.useGravity);
    }
}