using UnityEngine;
using UnityEngine.UIElements;

public class CheckpointTrigger : MonoBehaviour

{
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Vector3 cameraCurrent = Camera.main.transform.position;
            Vector3 playerCurrent = gameObject.transform.position;
            CustomGameManager.checkpointCam = cameraCurrent;
            CustomGameManager.playerStartPosition = playerCurrent;
        }
    }
}
