using UnityEngine;
using System.Collections;

public class AquamentusAI : MonoBehaviour
{
    public GameObject fireballPrefab;
    public float fireInterval = 2f;
    public float fireballSpawnDistance = 1f;
    public float spreadAngle = 20f;   // degrees between each of the 3 fireballs

    private Transform player;
    private Coroutine fireLoop;

    void Awake()
    {
        GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
        if (playerObj != null) player = playerObj.transform;
    }
    void OnEnable()
    {
        fireLoop = StartCoroutine(FireLoop());
    }

    void OnDisable()
    {
        if (fireLoop != null)
        {
            StopCoroutine(fireLoop);
            fireLoop = null;
        }
    }
    // void Start()
    // {
    //     GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
    //     if (playerObj != null) 
    //     {
    //         player = playerObj.transform;
    //     }

    //     StartCoroutine(FireLoop());
    // }

    private IEnumerator FireLoop()
    {
        while (true)
        {
            yield return new WaitForSeconds(fireInterval);
            FireVolley();
        }
    }

    private void FireVolley()
    {
        if (fireballPrefab == null || player == null) 
        {
            return;
        }

        Vector2 toPlayer = ((Vector2)player.position - (Vector2)transform.position).normalized;
        float centerAngle = Mathf.Atan2(toPlayer.y, toPlayer.x) * Mathf.Rad2Deg;

        // three fireballs: straight at player, and offset left/right by spreadAngle
        float[] angleOffsets = { -spreadAngle, 0f, spreadAngle };

        foreach (float offset in angleOffsets)
        {
            float angle = (centerAngle + offset) * Mathf.Deg2Rad;
            Vector2 direction = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));

            Vector3 spawnPos = transform.position + (Vector3)(direction * fireballSpawnDistance);
            GameObject fireball = Instantiate(fireballPrefab, spawnPos, Quaternion.identity);

            Beam beam = fireball.GetComponent<Beam>();
            if (beam != null)
            {
                beam.owner = transform.root;
                beam.SetDirection(direction);
                beam.IgnoreOwnerCollisions();
            }
        }
    }
}