using UnityEngine;

public class Door : MonoBehaviour
{
    public enum Axis { Vertical, Horizontal }

    [Tooltip("Vertical = north/south doorway. Horizontal = east/west doorway.")]
    public Axis axis = Axis.Vertical;

    public bool isLocked = false;
}