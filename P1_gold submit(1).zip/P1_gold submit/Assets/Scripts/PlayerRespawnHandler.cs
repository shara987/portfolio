using UnityEngine;

public class PlayerRespawnHandler : MonoBehaviour
{
public Vector3 respawnPosition = new Vector3(9f, 5.5f, 0f);

    private ArrowKeyMovement movement;
    private Rigidbody rb;

    void Awake()
    {
        movement = GetComponent<ArrowKeyMovement>();
        rb = GetComponent<Rigidbody>();
    }

    public void CaughtByWallMaster()
    {
        if (movement != null) movement.enabled = false;
        if (rb != null) rb.linearVelocity = Vector3.zero;

        transform.position = respawnPosition;
        Camera.main.transform.position = new Vector3(39.5f,7f,-10f);
        movement.enabled = true;
    }
}
