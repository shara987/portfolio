using System.Collections;
using UnityEngine;

public class RoomTransitions : MonoBehaviour
{
    public ArrowKeyMovement player;
    public float playerTranslationPostRoomTransition = 2.5f;
    public float screenTransitionDuration = 1.5f;
    private bool isTransitioning = false;

    void Update()
    {
        if(player.isDoorCollision && !isTransitioning){
            isTransitioning = true;
            StartCoroutine(WaitForPlayerTouchDoor());
        }
    }

    IEnumerator WaitForPlayerTouchDoor()
    {
        int capturedDirection = player.doorDirection;
        player.enabled = false;
        
        //disable weapons as well
        //disable enemy movement
        yield return StartCoroutine(ShiftCameraForDirection(capturedDirection));

        player.enabled = true;
        isTransitioning = false;
    }

    IEnumerator ShiftCameraForDirection(int direction)
    {
        Vector3 initialPosition = transform.position;
        Vector3 offset = GetScreenTranslation(direction);
        Vector3 targetPosition = initialPosition + offset;
        Vector2 playerPosition = player.transform.position;
        Vector2 offsetPlayer = GetPlayerTranslation(direction);
        Vector2 playerTarget = playerPosition + offsetPlayer;
        float elapsed = 0f;
        while(elapsed < screenTransitionDuration)
        {
            transform.position = Vector3.Lerp(initialPosition,targetPosition,elapsed/screenTransitionDuration);
            player.transform.position = Vector2.Lerp(playerPosition,playerTarget,elapsed/screenTransitionDuration);
            elapsed += Time.deltaTime;
            yield return null;
        }
        transform.position = targetPosition;
        player.transform.position = playerTarget;
        player.isDoorCollision = false;
        player.doorDirection = -1;
    }

    //0 = down
    // 1 = up
    // 2 = right
    // 3 = left
    Vector3 GetScreenTranslation(int direction)
    {
        switch (direction)
        {
            case 0: return new Vector3 (0,-11,0);
            case 1: return new Vector3 (0,11,0);
            case 2: return new Vector3 (16,0,0);
            case 3: return new Vector3 (-16,0,0);
            default: return Vector3.zero;
        }
    }

    Vector2 GetPlayerTranslation(int direction)
    {
        switch (direction)
        {
            case 0: return Vector2.down * playerTranslationPostRoomTransition;
            case 1: return Vector2.up * playerTranslationPostRoomTransition;
            case 2: return Vector2.right * playerTranslationPostRoomTransition;
            case 3: return Vector2.left * playerTranslationPostRoomTransition;
            default: return Vector2.zero;
        }
    }
}