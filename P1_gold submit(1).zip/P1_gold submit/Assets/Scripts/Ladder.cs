using UnityEngine;

public class Ladder : MonoBehaviour
{
    public float climbSpeed = 3f;

    private void OnTriggerStay(Collider other)
    {
        if (!other.CompareTag("Player"))
            return;

        Rigidbody rb = other.GetComponent<Rigidbody>();

        if (rb == null)
            return;

        float vertical = Input.GetAxisRaw("Vertical");

        Vector3 velocity = rb.linearVelocity;

        // Ladder 只负责上下
        velocity.y = vertical * climbSpeed;

        rb.linearVelocity = velocity;
    }
}