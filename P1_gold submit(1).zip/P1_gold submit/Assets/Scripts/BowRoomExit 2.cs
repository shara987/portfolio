// using UnityEngine;

// public class BowRoomExit : MonoBehaviour
// {
//     public Transform dungeonReturnPoint;
//     public Transform dungeonCameraTarget;
//     public Camera mainCamera;

//     private void OnTriggerEnter(Collider other)
//     {
//         if (!other.CompareTag("Player"))
//         {
//             return;
//         }

//         ArrowKeyMovement topDownMovement =
//             other.GetComponent<ArrowKeyMovement>();

//         SideScrollMovement sideMovement =
//             other.GetComponent<SideScrollMovement>();

//         Rigidbody rb =
//             other.GetComponent<Rigidbody>();

//         if (topDownMovement != null)
//         {
//             topDownMovement.enabled = true;
//         }

//         if (sideMovement != null)
//         {
//             sideMovement.enabled = false;
//         }

//         if (rb != null)
//         {
//             rb.linearVelocity = Vector3.zero;
//             rb.useGravity = false;
//         }

//         if (dungeonReturnPoint != null)
//         {
//             other.transform.position = dungeonReturnPoint.position;
//         }

//         if (mainCamera != null && dungeonCameraTarget != null)
//         {
//             mainCamera.transform.position = dungeonCameraTarget.position;
//         }
//     }
// }