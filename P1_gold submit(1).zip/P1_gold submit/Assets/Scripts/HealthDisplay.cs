using UnityEngine;
using UnityEngine.UI;

public class HealthDisplay : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public GameObject player;
    public Image[] halfHearts;
    private HasHealth playerHealth;
    void Start()
    {
        playerHealth = player.GetComponent<HasHealth>();
    }
    void Update()
    {
        int hp = Mathf.RoundToInt(playerHealth.GetHealth());

        for (int i = 0; i < halfHearts.Length; i++)
        {
            halfHearts[i].gameObject.SetActive(hp > i);
        }
    }

}
