using System.Collections.Generic;
using UnityEngine;

public class WallMaster : MonoBehaviour
{
public float moveSpeed = 3f;
    public bool isActive { get; private set; } = false;

    private Queue<Vector3> waypoints = new Queue<Vector3>();
    private Vector3 currentTarget;
    private bool hasTarget = false;

    private Rigidbody rb;
    private Collider col;
    private SpriteRenderer sr;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        col = GetComponent<Collider>();
        sr = GetComponent<SpriteRenderer>();

        if (rb != null) rb.isKinematic = true; // moved manually via transform, not physics forces

        Deactivate(); // start hidden/inactive, sitting in the pool
    }

    public void Activate(List<Vector3> path)
    {
        if (path == null || path.Count == 0) return;

        waypoints.Clear();
        foreach (var point in path) waypoints.Enqueue(point);

        transform.position = waypoints.Dequeue(); // snap to spawn point instantly
        isActive = true;
        if (col != null) col.enabled = true;
        if (sr != null) sr.enabled = true;

        AdvanceTarget();
    }

    void AdvanceTarget()
    {
        if (waypoints.Count > 0)
        {
            currentTarget = waypoints.Dequeue();
            hasTarget = true;
        }
        else
        {
            hasTarget = false;
            Deactivate(); // path finished — return to pool, no Destroy()
        }
    }

    void Deactivate()
    {
        isActive = false;
        if (col != null) col.enabled = false;
        if (sr != null) sr.enabled = false;
    }

    void Update()
    {
        if (!isActive || !hasTarget) return;

        transform.position = Vector3.MoveTowards(transform.position, currentTarget, moveSpeed * Time.deltaTime);

        if (Vector3.Distance(transform.position, currentTarget) < 0.01f)
        {
            AdvanceTarget();
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (!isActive) return;

        if (collision.gameObject.CompareTag("Player"))
        {
            PlayerRespawnHandler respawn = collision.gameObject.GetComponent<PlayerRespawnHandler>();
            if (respawn != null)
            {
                respawn.CaughtByWallMaster();
            }
        }
    }
}
