// using UnityEngine;

// public class Collector : MonoBehaviour
// {
//     // Start is called once before the first execution of Update after the MonoBehaviour is created
//     public AudioClip rupee_collection_sound_clip;
//     Inventory inventory;
//     void Start()
//     {
//         inventory = GetComponent<Inventory>();
//         if (inventory == null)
//         {
//             Debug.LogWarning("WARNING: Gameobject with a collector has no inventory to store things in!");
//         }
//     }
//     void OnTriggerEnter(Collider coll)
//     {
//         Debug.Log("Touched: " + coll.gameObject.name);
//         GameObject object_collided_with = coll.gameObject;
//         if (object_collided_with.tag == "rupee")
//         {
//             if (inventory != null)
//                 inventory.AddRupees(1);
//             Destroy (object_collided_with);

//             AudioSource.PlayClipAtPoint (rupee_collection_sound_clip, Camera.main.transform.position);
//         }
//     }

//     // Update is called once per frame
    
// }
