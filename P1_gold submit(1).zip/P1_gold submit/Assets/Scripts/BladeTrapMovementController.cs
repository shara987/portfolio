using UnityEngine;

public class BladeTrapMovementController : MonoBehaviour
{
    public float moveSpeed = 4f;

    public enum State { Idle, MovingOut, Returning }
    public State currentState { get; private set; } = State.Idle;

    private Vector3 homePosition;
    private Vector3 targetPosition;

    public bool IsAvailable => currentState == State.Idle;

    void Start()
    {
        homePosition = transform.position;
    }

    public void MoveToMiddle(Vector3 middlePoint)
    {
        if (!IsAvailable) return;

        targetPosition = middlePoint;
        currentState = State.MovingOut;
    }

    void Update()
    {
        if (currentState == State.Idle) return;

        transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);

        if (Vector3.Distance(transform.position, targetPosition) < 0.01f)
        {
            if (currentState == State.MovingOut)
            {
                // Reached the midpoint — immediately head home, regardless
                // of whether the player is still on the edge.
                targetPosition = homePosition;
                currentState = State.Returning;
            }
            else if (currentState == State.Returning)
            {
                currentState = State.Idle;
            }
        }
    }
}
