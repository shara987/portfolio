using UnityEngine;

public class Knockback : MonoBehaviour
{
    public float knockbackStrength = 10f;
    public float knockbackCooldown = 0.25f;
    GridBasedMovement grid;
    void OnCollisionEnter(Collision other)
    {
        Rigidbody other_rb = other.gameObject.GetComponent<Rigidbody>();
        if (other_rb == null) return;

        Vector2 from_us_to_them = other.gameObject.transform.position - transform.position;
        Vector2 cardinal = SnapToCardinalDirection(from_us_to_them.normalized);

        if (other.gameObject.CompareTag("Player"))
        {
            var stun = other.gameObject.GetComponent<PlayerStunHandler>();
            if (stun != null) stun.ApplyKnockback(cardinal * knockbackStrength, knockbackCooldown);
        }
        else if (other.gameObject.CompareTag("enemy"))
        {
            var stun = other.gameObject.GetComponent<EnemyStunHandler>();
            if (stun != null) stun.ApplyKnockback(cardinal * knockbackStrength, knockbackCooldown);
        }
    }

    Vector2 SnapToCardinalDirection(Vector2 direction)
    {
        if (Mathf.Abs(direction.x) > Mathf.Abs(direction.y))
        {
            return new Vector2(Mathf.Sign(direction.x), 0f);
        }
        else
        {
            return new Vector2(0f, Mathf.Sign(direction.y));
        }
    }


}