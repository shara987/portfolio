using UnityEngine;

public class IsCracked : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (!ArrowKeyMovement.isCracked)
            {
                ArrowKeyMovement.isCracked = true;
            }
            if (ArrowKeyMovement.isCracked)
            {
                ArrowKeyMovement.timerSinceCracked = 0;
            }
            Destroy(gameObject);
        }
    }
}
