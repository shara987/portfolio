using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;


public class HasHealth : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public float maxHealth = 6f;
    public float hp;
    public float powerfulTime = 1.0f;
    private float lastDamageTime = -999f;
    private SpriteRenderer spriteRenderer;
    private ArrowKeyMovement movement;
    public bool isHitStunned = false;
    public CustomGameManager customGame;
    void Start()
    {
        hp = maxHealth;
        spriteRenderer = GetComponent<SpriteRenderer>();
        movement = GetComponent<ArrowKeyMovement>();
    }

    public void AlterHealth(float delta)
    {
        if (delta < 0)
        {
            if (HasInventory.god_mode)
            {
                Debug.Log("Damage blocked: GOD MODE");
                return;
            }
            if(Time.time - lastDamageTime < powerfulTime)
            {
                Debug.Log("Damage ignored: player is invincible.");
                return;
            }
            lastDamageTime = Time.time;
            StartCoroutine(Flash());
            Debug.Log("Damage accepted at time: " + Time.time);
        }
        hp += delta;
        hp = Mathf.Clamp(hp, 0, maxHealth);
        if (hp <= 0)
        {
            Die();
        }
    }

    IEnumerator Flash()
    {
        for (int i = 0; i < 3; i++)
        {
            spriteRenderer.enabled = false;
            yield return new WaitForSeconds(0.1f);
            spriteRenderer.enabled = true;
            yield return new WaitForSeconds(0.1f);
        }
    }

    IEnumerator HitStun(Vector3 knockbackDirection)
    {
        isHitStunned = true;
        movement.enabled = false;

        Rigidbody rb = GetComponent<Rigidbody>();

        rb.linearVelocity = knockbackDirection * 5f;

        yield return new WaitForSeconds(0.25f);

        rb.linearVelocity = Vector3.zero;

        movement.enabled = true;
        isHitStunned = false;
    }

    public void TakeDamage(float damage, Vector3 attackerPosition)
    {
        float oldHp = hp;
        AlterHealth(-damage);
        if(hp == oldHp)
        {
            return;
        }
        
        Vector3 knockbackDirection = (transform.position - attackerPosition).normalized;
        StartCoroutine(HitStun(knockbackDirection));

    }

    public float GetHealth()
    {
        return hp;
    }

    public void Die()
    {
        if (customGame.customLevelPlaying)
        {
            customGame.SetCheckpoint();
        }
        else
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.H))
        {
            Vector3 fakeAttackerPosition = transform.position + Vector3.right;
            TakeDamage(1, fakeAttackerPosition);
        }

        

    }
}
