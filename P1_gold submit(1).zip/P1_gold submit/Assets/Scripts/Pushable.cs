using System.Collections;
using UnityEngine;

public class PushableBlock : MonoBehaviour
{
    public float pushDelay = 0.4f;
    public float gridSize = 1f;
    public float moveDuration = 0.2f;

    private float pushTimer = 0f;
    private bool isMoving = false;

    void OnCollisionStay(Collision collision)
    {
        if (isMoving)
        {
            return;
        }

        if (!collision.gameObject.CompareTag("Player"))
        {
            return;
        }

        // 直接读取键盘输入
        float horizontalInput = Input.GetAxisRaw("Horizontal");
        float verticalInput = Input.GetAxisRaw("Vertical");

        // 和你的 ArrowKeyMovement 保持一致：
        // 有水平输入时忽略垂直输入
        if (Mathf.Abs(horizontalInput) > 0.0f)
        {
            verticalInput = 0.0f;
        }

        Vector2 input =
            new Vector2(horizontalInput, verticalInput);

        if (input == Vector2.zero)
        {
            pushTimer = 0f;
            return;
        }

        // 判断方块相对于 Player 的方向
        Vector3 difference =
            transform.position - collision.transform.position;

        Vector2 pushDirection;

        if (Mathf.Abs(difference.x) > Mathf.Abs(difference.y))
        {
            pushDirection =
                new Vector2(
                    Mathf.Sign(difference.x),
                    0f
                );
        }
        else
        {
            pushDirection =
                new Vector2(
                    0f,
                    Mathf.Sign(difference.y)
                );
        }

        // 只有玩家真的朝方块方向推，才开始计时
        if (input == pushDirection)
        {
            pushTimer += Time.deltaTime;

            if (pushTimer >= pushDelay)
            {
                pushTimer = 0f;

                StartCoroutine(
                    MoveOneGrid(pushDirection)
                );
            }
        }
        else
        {
            pushTimer = 0f;
        }
    }

    void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            pushTimer = 0f;
        }
    }

    IEnumerator MoveOneGrid(Vector2 direction)
    {
        isMoving = true;

        Vector3 startPosition = transform.position;

        Vector3 targetPosition =
            startPosition +
            new Vector3(
                direction.x,
                direction.y,
                0f
            ) * gridSize;

        float elapsed = 0f;

        while (elapsed < moveDuration)
        {
            transform.position =
                Vector3.Lerp(
                    startPosition,
                    targetPosition,
                    elapsed / moveDuration
                );

            elapsed += Time.deltaTime;

            yield return null;
        }

        transform.position = targetPosition;

        isMoving = false;
    }
}