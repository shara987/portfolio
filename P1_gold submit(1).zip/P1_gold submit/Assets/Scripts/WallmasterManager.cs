using System.Collections.Generic;
using UnityEngine;

public class WallmasterManager : MonoBehaviour
{
    public enum Edge { Left, Right, Top, Bottom }

    [System.Serializable]
    public class EdgeConfig
    {
        public Edge edge;
        public Transform cornerA;
        public Transform cornerB;
        public float cooldown = 3f;
        [HideInInspector] public float cooldownTimer = 0f;
    }

    public EdgeConfig[] edges = new EdgeConfig[4];
    public WallMaster[] wallMasterPool = new WallMaster[6];
    public Transform player;
    public LayerMask playerLayer;
    public float tileSize = 1f;
    public int sweepTileCount = 4; // how many tiles it travels ALONG the wall
    public float spawnOffset = 1f;

    void Update()
    {
        foreach (var edgeConfig in edges)
        {
            if (edgeConfig.cooldownTimer > 0f)
            {
                edgeConfig.cooldownTimer -= Time.deltaTime;
            }

            bool hit = Physics.Linecast(edgeConfig.cornerA.position, edgeConfig.cornerB.position, playerLayer);

            if (hit && edgeConfig.cooldownTimer <= 0f)
            {
                WallMaster free = FindAvailableWallMaster();
                if (free != null)
                {
                    free.Activate(BuildPath(edgeConfig));
                    edgeConfig.cooldownTimer = edgeConfig.cooldown;
                }
            }
        }
    }

    WallMaster FindAvailableWallMaster()
    {
        foreach (var wm in wallMasterPool)
        {
            if (wm != null && !wm.isActive) return wm;
        }
        return null;
    }

    List<Vector3> BuildPath(EdgeConfig edgeConfig)
    {
        List<Vector3> path = new List<Vector3>();
        bool isVertical = (edgeConfig.edge == Edge.Left || edgeConfig.edge == Edge.Right);

        float wallCoord = isVertical ? edgeConfig.cornerA.position.x : edgeConfig.cornerA.position.y;
        float playerCoord = isVertical ? player.position.y : player.position.x;

        // The two corner values along the wall's own axis
        float cornerAVal = isVertical ? edgeConfig.cornerA.position.y : edgeConfig.cornerA.position.x;
        float cornerBVal = isVertical ? edgeConfig.cornerB.position.y : edgeConfig.cornerB.position.x;

        bool nearIsA = Mathf.Abs(playerCoord - cornerAVal) < Mathf.Abs(playerCoord - cornerBVal);
        float spawnAlongWall = nearIsA ? cornerAVal : cornerBVal;
        float farAlongWall = nearIsA ? cornerBVal : cornerAVal;

        float direction = Mathf.Sign(farAlongWall - spawnAlongWall);

        // Outward (perpendicular) coordinates
        float spawnPerp, entryPerp;
        switch (edgeConfig.edge)
        {
            case Edge.Left:   spawnPerp = wallCoord - spawnOffset; entryPerp = wallCoord; break;
            case Edge.Right:  spawnPerp = wallCoord + spawnOffset; entryPerp = wallCoord; break;
            case Edge.Bottom: spawnPerp = wallCoord - spawnOffset; entryPerp = wallCoord; break;
            case Edge.Top:    spawnPerp = wallCoord + spawnOffset; entryPerp = wallCoord; break;
            default:          spawnPerp = wallCoord; entryPerp = wallCoord; break;
        }

        // 1. Spawn outside the wall, aligned with the chosen corner
        path.Add(MakePoint(isVertical, spawnPerp, spawnAlongWall));
        // 2. Step one tile inward, still at the corner's row/column
        path.Add(MakePoint(isVertical, entryPerp, spawnAlongWall));

        // 3. Sweep along the wall, tile by tile, toward the far corner,
        //    clamped so it never overshoots past the far corner
        float current = spawnAlongWall;
        for (int i = 1; i <= sweepTileCount; i++)
        {
            float next = spawnAlongWall + direction * i * tileSize;
            if (direction > 0) next = Mathf.Min(next, farAlongWall);
            else next = Mathf.Max(next, farAlongWall);

            path.Add(MakePoint(isVertical, entryPerp, next));
            current = next;
        }

        // 4. Retreat straight back out through the wall from wherever the sweep ended
        path.Add(MakePoint(isVertical, spawnPerp, current));

        return path;
    }

    Vector3 MakePoint(bool isVertical, float perpVal, float alongVal)
    {
        return isVertical ? new Vector3(perpVal, alongVal, 0f) : new Vector3(alongVal, perpVal, 0f);
    }
}
