using UnityEngine;

public class GridBasedMovement : MonoBehaviour
{
    public float grid_size = 0.5f;
    public float snap_tolerance = 0.05f;
    public Vector2 GridSnapping(Vector2 input, float speed = -1f)
    {
        if(input == Vector2.zero)
        {
            return Vector2.zero;
        }
        Vector3 position = transform.position;
        
        if (input.y != 0)
        {
            float targetX =
                Mathf.Round(position.x / grid_size) * grid_size;

            float differenceX = targetX - position.x;

            if (Mathf.Abs(differenceX) > snap_tolerance)
            {
                if (speed > 0f && speed * Time.deltaTime >= Mathf.Abs(differenceX))
                {
                    // This frame's movement would reach (or overshoot) the line — snap directly instead
                    Vector3 snappedNow = transform.position;
                    snappedNow.x = targetX;
                    transform.position = snappedNow;
                    return new Vector2(0, input.y);
                }

                return new Vector2(
                    Mathf.Sign(differenceX),
                    0
                );
            }
        Vector3 snappedPosition = transform.position;
            snappedPosition.x = targetX;
            transform.position = snappedPosition;

            return new Vector2(0, input.y);
        }
        if (input.x != 0)
        {
            float targetY =
                Mathf.Round(position.y / grid_size) * grid_size;

            float differenceY = targetY - position.y;

            if (Mathf.Abs(differenceY) > snap_tolerance)
            {
                if (speed > 0f && speed * Time.deltaTime >= Mathf.Abs(differenceY))
                {
                    Vector3 snappedNow = transform.position;
                    snappedNow.y = targetY;
                    transform.position = snappedNow;
                    return new Vector2(input.x, 0);
                }
                return new Vector2(0, Mathf.Sign(differenceY));
            }

            
            Vector3 snappedPosition = transform.position;
            snappedPosition.y = targetY;
            transform.position = snappedPosition;

            return new Vector2(input.x, 0);
        }

        return Vector2.zero;
    }

}
