using UnityEngine;

public class EnemyRoomManager : MonoBehaviour
{
    public GameObject[] enemies;
    public Transform TopLeft;
    public Transform camerah;
    public GameObject loot;
    public Vector3 lootPosition;

    private bool hasSpawned = false;
    private bool lootDropped = false;
    private bool? roomActive = null; // null = not evaluated yet, so the first frame always applies a state
    //public GameObject slidingDoorObject;

    void Update()
    {
        bool playerInRoom =
            Mathf.Abs(camerah.position.x - (TopLeft.position.x + 5.5f)) < 0.05f &&
            Mathf.Abs(camerah.position.y - (TopLeft.position.y - 1f)) < 0.05f;

        if (roomActive != playerInRoom)
        {
            roomActive = playerInRoom;

            if (playerInRoom && !hasSpawned)
            {
                ShowEnemies();
                hasSpawned = true;
            }
            SetEnemiesActive(playerInRoom);
        }
        //get sliding door to work wout messing up droploot
        // if (playerInRoom)
        // {
        //     if (slidedoor.playerEntered)
        //         {
        //             slidingDoorObject.SetActive(true);
        //         }
        //     if(GetEnemyRoomTotal() == 0)
        //     {
        //         slidingDoorObject.SetActive(false);
        //     }
        // }

        if (hasSpawned && !lootDropped && GetEnemyRoomTotal() == 0)
        {
            Instantiate(loot, lootPosition, Quaternion.identity);
            lootDropped = true;
        }
    }

    void ShowEnemies()
    {
        foreach (GameObject enemy in enemies)
        {
            if (enemy == null) continue;
            SpriteRenderer sr = enemy.GetComponent<SpriteRenderer>();
            if (sr != null) sr.enabled = true;
        }
    }

    void SetEnemiesActive(bool isActive)
    {
        foreach (GameObject enemy in enemies)
        {
            if (enemy == null) continue;

            SetEnabled<RandomMovementController>(enemy, isActive);
            SetEnabled<RandomMovementGel>(enemy, isActive);
            SetEnabled<RandomDiagonalMovement>(enemy, isActive);
            SetEnabled<Goriya_Attack>(enemy, isActive);
            SetEnabled<AquamentusAI>(enemy, isActive);

            // if(enemy.GetComponent<RandomMovementController>() != null)
            if (enemy.name.Contains("Stalfo"))
            {
                Animator stalfoAnimation;
                stalfoAnimation = enemy.GetComponent<Animator>();
                stalfoAnimation.enabled = isActive;

            }
            //enemy.GetComponent<Animator>().enabled = isActive;    //stalfo
            SetEnabled<FlashingAesthetic>(enemy, isActive);            // Keese, Gel
            SetEnabled<DirectionalSpriteAnimation>(enemy, isActive);   // Goriya
            }
    }

    void SetEnabled<T>(GameObject go, bool state) where T : MonoBehaviour
    {
        T comp = go.GetComponent<T>();
        if (comp != null) comp.enabled = state;
    }

    int GetEnemyRoomTotal()
    {
        int count = 0;
        foreach (GameObject enemy in enemies)
        {
            if (enemy != null) count++;
        }
        return count;
    }
}

//TODO: disable animations
//stalfo: uncheck animator
//keese: uncheck flashingAesthetic script
//gel: uncheck flashingAesthetic script
//goriya: uncheck directional sprite animation script
//bigboss: idk yet wait for sharanya code
