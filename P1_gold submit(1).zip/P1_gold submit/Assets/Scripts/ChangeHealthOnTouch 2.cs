// using NUnit.Framework;
// using UnityEngine;

// public class ChangeHealthOnTouch : MonoBehaviour
// {
//     HasHp enemyHealth;

//     HasHealth playerHealth;
//     public float dealDamage = 1f;
//     EnemyStunHandler enemyStunned;
//     PlayerStunHandler playerStunned;
//     public bool isTrigger = false;




//     void OnCollisionEnter(Collision collision)
//     {
//         enemyHealth = collision.gameObject.GetComponentInParent<HasHp>();
//         playerHealth = collision.gameObject.GetComponentInParent<HasHealth>();
//         //enemyStunned = collision.gameObject.GetComponent<EnemyStunHandler>();
//         //playerStunned = collision.gameObject.GetComponent<PlayerStunHandler>();
//         if(CompareTag("weapon") && collision.gameObject.CompareTag("enemy"))
//         {
//             losehp(0);
//         }

//         if (CompareTag("enemy") && collision.transform.root.CompareTag("Player"))
//         {
//             losehp(1);
//         }
//         if (ArrowKeyMovement.isCracked && CompareTag("Player") && collision.gameObject.CompareTag("enemy"))
//         {
//             losehp(0);
//         }
//     }
//     void OnTriggerEnter(Collider other)
//     {
//         if (isTrigger)
//         {
//             playerHealth = other.gameObject.GetComponentInParent<HasHealth>();
//             if (CompareTag("enemy") && other.transform.root.CompareTag("Player"))
//             {
//                 losehp(1);
//             }
//         }
//     }
//     //if im enemy and weapon touches me -> lose hp

//     //if player and enemy touches me -> lose hp
//     void losehp(int type)
//     {
//         if (type == 0)
//         {
//             if (enemyHealth == null) { Debug.Log("NO ENEMY HEALTH"); return; }
//             if (ArrowKeyMovement.isCracked)
//             {
//                 enemyHealth.TakeDamage(10000f, transform.position);
//             }
//             else
//             {
//                 enemyHealth.TakeDamage(dealDamage, transform.position);
//             }
//         }

//         if (type == 1)
//         {
//             if (playerHealth == null || ArrowKeyMovement.isCracked) return;
//             // No isInvincible check — HasHealth.powerfulTime already handles i-frames.
//             playerHealth.TakeDamage(dealDamage, transform.position);
//         }
//     }
// }
