using UnityEngine;

public class Cheat : MonoBehaviour
{
    public HasInventory inventory;
    public WeaponHandler weaponHandler;

    void Awake() => HasInventory.god_mode = false; 
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            HasInventory.god_mode = !HasInventory.god_mode;
            //Debug.Log($"GOD MODE = {HasInventory.god_mode}");

            if (HasInventory.god_mode)
            {
                if (inventory != null) inventory.MaxItems();
                if (weaponHandler != null) weaponHandler.UnlockAllSecondaries();
            }
        }
    }
}