using UnityEngine;
using System.Collections.Generic;

public class WeaponHandler : MonoBehaviour
{
    public Weapon primaryWeapon;
    public List<Weapon> allSecondaries = new List<Weapon>();      // every weapon that exists
    public List<Weapon> unlockedSecondaries = new List<Weapon>(); // starts EMPTY

    private int secondaryIndex = 0;
    private PlayerSpriteAnimation spriteAnim;

    public Weapon CurrentSecondary =>
        unlockedSecondaries.Count == 0 ? null : unlockedSecondaries[secondaryIndex];

    private bool inDoorway = false;
    

    void Start()
    {
        spriteAnim = GetComponent<PlayerSpriteAnimation>();

        // Everything off by default; unlocking re-enables.
        foreach (var w in allSecondaries)
            if (w != null) w.enabled = false;

        foreach (var w in unlockedSecondaries)
            if (w != null) w.enabled = true;

        if (CurrentSecondary != null) CurrentSecondary.SwappedIn();
    }

    public void UnlockSecondary(Weapon w)
    {
        if (w == null || unlockedSecondaries.Contains(w)) return;

        unlockedSecondaries.Add(w);
        w.enabled = true;

        // First weapon acquired becomes the active one.
        if (unlockedSecondaries.Count == 1)
        {
            secondaryIndex = 0;
            w.SwappedIn();
        }
    }

    public bool HasSecondary(Weapon w) => unlockedSecondaries.Contains(w);

    void Update()
    {
        int direction = spriteAnim.GetLastDirection();

        if (Input.GetKeyDown(KeyCode.X) && primaryWeapon != null && !inDoorway)
            primaryWeapon.Use(direction);

        if (Input.GetKeyDown(KeyCode.Z) && CurrentSecondary != null && !inDoorway)
            CurrentSecondary.Use(direction);

        if (Input.GetKeyDown(KeyCode.C) && unlockedSecondaries.Count > 1 && !inDoorway)
            CycleSecondary();
    }

    void CycleSecondary()
    {
        CurrentSecondary.SwappedOut();
        secondaryIndex = (secondaryIndex + 1) % unlockedSecondaries.Count;
        CurrentSecondary.SwappedIn();
    }

    public void UnlockAllSecondaries()
    {
        foreach (var w in allSecondaries)
            UnlockSecondary(w);
    }

    // void OnColliderStay(Collider other)
    // {
    //     if (other.gameObject.CompareTag("doorway"))
    //     {
    //         inDoorway = true;
    //         Debug.LogError($"'{inDoorway}' is DOORWAY!");
    //     }
    // }
    // void OnColliderExit(Collider other)
    // {
    //     if (other.gameObject.CompareTag("doorway"))
    //     {
    //         inDoorway = false;
    //     }
    // }
}
