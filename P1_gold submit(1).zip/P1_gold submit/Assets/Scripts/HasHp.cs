using UnityEngine;

public class HasHp : MonoBehaviour
{
    public AudioClip hitSound;
    public AudioClip deathSound;
    public float health = 3f;
    public GameObject loot;
    public float invulnTime = 0.35f;
    public float knockbackStrength = 10f;
    public float knockbackDuration = 0.25f;

    private float lastHitTime = -999f;
    private EnemyStunHandler stun;

    void Awake() => stun = GetComponent<EnemyStunHandler>();

    public bool TakeDamage(float amount, Vector3 sourcePosition)
    {
        if (amount <= 0f) return false;

        // invulnTime is the ONLY gate. Do not also check stun.isInvincible.
        if (Time.time - lastHitTime < invulnTime)
        {
            Debug.Log($"{name} ignored {amount} (i-frames)", this);
            return false;
        }

        lastHitTime = Time.time;
        health -= amount;
        if (hitSound != null)
        {
            AudioSource.PlayClipAtPoint(hitSound, transform.position);
        }

        Debug.Log($"{name} took {amount} → {health}", this);

        if (health <= 0f) { Die(); return true; }

        if (stun != null)
        {
            Vector2 dir = SnapToCardinal(
                ((Vector2)(transform.position - sourcePosition)).normalized);
            stun.ApplyKnockback(dir * knockbackStrength, knockbackDuration);
        }
        return true;
    }

    private Vector2 SnapToCardinal(Vector2 d) =>
        Mathf.Abs(d.x) > Mathf.Abs(d.y)
            ? new Vector2(Mathf.Sign(d.x), 0f)
            : new Vector2(0f, Mathf.Sign(d.y));

    private void Die()
    {
        if (deathSound != null)
        {
            AudioSource.PlayClipAtPoint(deathSound, transform.position);
        }
        if (loot != null) 
        {
            Instantiate(loot, transform.position, Quaternion.identity);
        }
        Destroy(gameObject);
    }
}
