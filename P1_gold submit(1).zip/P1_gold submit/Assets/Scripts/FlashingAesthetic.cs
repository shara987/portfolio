using UnityEngine;

public class FlashingAesthetic : MonoBehaviour
{

    public Sprite sprite1;
    public Sprite sprite2;
    public bool hasThirdSprite = false;
    public Sprite sprite3;
    public float intervalBtwnSprites = 0.2f;
    
    //public bool alwaysFlash = false;
    //public float flashLength = 3.0f;
    //public bool wasHit = false;
    private SpriteRenderer spriteRenderer;
    private float timer = 0f;
    private bool showing1 = true;
    private bool showing2 = false;
    private bool showing3 = false;
    
    // private Coroutine flashCoroutine;


    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }
    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if (!hasThirdSprite)
        {
            if (timer >= intervalBtwnSprites)
            {
                timer = 0f;
                showing1 = !showing1;
                spriteRenderer.sprite = showing1 ? sprite1 : sprite2;
            }
        }
        else
        {
            if (timer >= intervalBtwnSprites)
            {
                timer = 0f;
                if (showing1)
                {
                    spriteRenderer.sprite = sprite2;
                    showing1 = false;
                    showing2 = true;
                }
                else if (showing2)
                {
                    spriteRenderer.sprite = sprite3;
                    showing2 = false;
                    showing3 = true;
                }
                else if (showing3)
                {
                    spriteRenderer.sprite = sprite1;
                    showing3 = false;
                    showing1 = true;
                }
            }
        }
        
    }

    // void Start()
    // {
    //     spriteRenderer = GetComponent<SpriteRenderer>();

    //     if (alwaysFlash)
    //     {
    //         flashCoroutine = StartCoroutine(FlashForever());
    //     }
    // }

    // void Update()
    // {
    //     if (wasHit)
    //     {
    //         wasHit = false;

    //         // Stop any current flashing so we don't run two flash routines at once
    //         if (flashCoroutine != null)
    //         {
    //             StopCoroutine(flashCoroutine);
    //         }

    //         flashCoroutine = StartCoroutine(FlashForDuration(flashLength));
    //     }
    // }

    // IEnumerator FlashForDuration(float duration)
    // {
    //     float elapsed = 0f;
    //     while (elapsed < duration)
    //     {
    //         ToggleSprite();
    //         yield return new WaitForSeconds(intervalBtwnSprites);
    //         elapsed += intervalBtwnSprites;
    //     }

    //     // Reset to a known default sprite once flashing ends
    //     spriteRenderer.sprite = sprite1;
    //     showing1 = true;

    //     // If alwaysFlash is on, resume continuous flashing after the hit-flash ends
    //     if (alwaysFlash)
    //     {
    //         flashCoroutine = StartCoroutine(FlashForever());
    //     }
    // }

    // IEnumerator FlashForever()
    // {
    //     while (true)
    //     {
    //         ToggleSprite();
    //         yield return new WaitForSeconds(intervalBtwnSprites);
    //     }
    // }

    // void ToggleSprite()
    // {
    //     showing1 = !showing1;
    //     spriteRenderer.sprite = showing1 ? sprite1 : sprite2;
    // }
}
