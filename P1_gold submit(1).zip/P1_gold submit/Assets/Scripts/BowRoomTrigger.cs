using UnityEngine;

public class BowRoomTrigger : MonoBehaviour
{
    public Transform bowRoomSpawn;
    public Transform bowRoomCameraTarget;
    public Camera mainCamera;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player"))
            return;

        ArrowKeyMovement topDown =
            other.GetComponent<ArrowKeyMovement>();

        SideScrollMovement side =
            other.GetComponent<SideScrollMovement>();

        Rigidbody rb =
            other.GetComponent<Rigidbody>();

        if (topDown != null)
            topDown.enabled = false;

        if (side != null)
            side.enabled = true;

        if (bowRoomSpawn != null)
            other.transform.position = bowRoomSpawn.position;

        if (rb != null)
        {
            rb.linearVelocity = Vector3.zero;
            rb.useGravity = true;   // 进入 Bow Room：开 gravity
        }

        if (mainCamera != null &&
            bowRoomCameraTarget != null)
        {
            mainCamera.transform.position =
                bowRoomCameraTarget.position;
        }
    }
}