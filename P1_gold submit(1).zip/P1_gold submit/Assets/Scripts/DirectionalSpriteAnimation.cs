using UnityEngine;

public class DirectionalSpriteAnimation : MonoBehaviour
{
    public Sprite down;
    public Sprite up;
    public Sprite right;
    public Sprite right2;
    public float animationSpeed = 0.15f;
    private SpriteRenderer spriteRenderer;
    private Rigidbody rb;
    private float timer = 0f;
    private bool secondFrame = false;
    public int lastDirection { get; private set; } = 0;
    void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody>();
    }
    void Update()
    {
        Vector3 velocity = rb.linearVelocity;
        timer += Time.deltaTime;
        if(timer >= animationSpeed)
        {
            timer = 0f;
            secondFrame = !secondFrame;
        }
        if (velocity.x > 0.01f)
        {
            //going right
           lastDirection = 2;
        }

        else if (velocity.x < -0.01f)
        {
            //going left
            lastDirection = 3;
        }

        else if (velocity.y > 0.01f)
        {
            //going up
            lastDirection = 1;
        }

        else if (velocity.y < -0.01f)
        {
            //going down
            lastDirection = 0;
        }
        ApplySprite();
    }

    void ApplySprite()
    {
        switch (lastDirection)
        {
            case 0: //down
            spriteRenderer.sprite = down;
            spriteRenderer.flipX = secondFrame;
            break;
            case 1: //up
            spriteRenderer.sprite = up;
            spriteRenderer.flipX = secondFrame;
            break;
            case 2: //right
            spriteRenderer.sprite = secondFrame ? right2 : right;
            spriteRenderer.flipX = false;
            break;
            case 3: //left
            spriteRenderer.sprite = secondFrame ? right2 : right;
            spriteRenderer.flipX = true;
            break;
        }
    }

}
