using UnityEngine;

public class SideScrollMovement : MonoBehaviour
{
    public float moveSpeed = 4f;

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        float horizontal = Input.GetAxisRaw("Horizontal");

        Vector3 velocity = rb.linearVelocity;
        velocity.x = horizontal * moveSpeed;

        rb.linearVelocity = velocity;
    }
}