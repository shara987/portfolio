using UnityEngine;

public class OldManDialogueTrigger : MonoBehaviour
{
    public GameObject dialogueObject;

    private bool playerInside = false;
    private bool dialogueVisible = false;

    void Start()
    {
        if (dialogueObject != null)
        {
            dialogueObject.SetActive(false);
        }
    }

    void Update()
    {
        if (playerInside && dialogueVisible && Input.GetKeyDown(KeyCode.Space))
        {
            dialogueObject.SetActive(false);
            dialogueVisible = false;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player"))
        {
            return;
        }

        playerInside = true;

        if (dialogueObject != null)
        {
            dialogueObject.SetActive(true);
            dialogueVisible = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (!other.CompareTag("Player"))
        {
            return;
        }

        playerInside = false;

        if (dialogueObject != null)
        {
            dialogueObject.SetActive(false);
            dialogueVisible = false;
        }
    }
}