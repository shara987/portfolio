using System.Collections;
using UnityEngine;

public class RandomDiagonalMovement : MonoBehaviour
{
   public float minSpeed = 1f;
    public float maxSpeed = 3f;
    public float minMoveDuration = 0.3f;
    public float maxMoveDuration = 1f;
    public float minPauseDuration = 0.1f;
    public float maxPauseDuration = 0.5f;
    [Range(0f, 1f)] public float chanceToPause = 0.3f; // 30% chance to pause instead of moving next

    Rigidbody rb;
    Coroutine currentMove;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    void OnEnable()
    {
        currentMove = StartCoroutine(Move());
    }

    void OnDisable()
    {
        if (currentMove != null)
        {
            StopCoroutine(currentMove);
            currentMove = null;
        }
        if (rb != null) rb.linearVelocity = Vector3.zero;
    }
    // void Start()
    // {
    //     rb = GetComponent<Rigidbody>();
    //     currentMove = StartCoroutine(Move());
    // }

    IEnumerator Move()
    {
        while (true)
        {
            if (Random.value < chanceToPause)
            {
                // Rest for a moment, like a Keese pausing mid-flight
                rb.linearVelocity = Vector3.zero;
                float pauseTime = Random.Range(minPauseDuration, maxPauseDuration);
                yield return new WaitForSeconds(pauseTime);
            }
            else
            {
                // Pick a random direction, INCLUDING diagonals — full 360, not just 4 cardinal dirs
                Vector2 direction = Random.insideUnitCircle.normalized;
                float speed = Random.Range(minSpeed, maxSpeed);
                float moveTime = Random.Range(minMoveDuration, maxMoveDuration);

                float elapsed = 0f;
                while (elapsed < moveTime)
                {
                    rb.linearVelocity = direction * speed;
                    elapsed += Time.deltaTime;
                    yield return null;
                }
            }
        }
    }

    void OnCollisionStay()
    {
        if (!enabled) return; // physics messages still arrive while the script is disabled
        if (currentMove != null) StopCoroutine(currentMove);
        currentMove = StartCoroutine(Move());
    }
}
