using UnityEngine;

public class HasInventory : MonoBehaviour
{
    public int rupees = 0;
    public int bombs = 0;
    public int keys = 0;

    public AudioClip rupee_collection_sound_clip;
    public AudioClip heart_collection_sound_clip;

    public static bool god_mode = false;

    public Weapon bombWeapon;
    public Weapon boomerangWeapon;
    public Weapon bowWeapon;

    private WeaponHandler weaponHandler;

    void Start()
    {
        weaponHandler = GetComponent<WeaponHandler>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("rupee"))
        {
            rupees++;
            Destroy(other.gameObject);
            AudioSource.PlayClipAtPoint(rupee_collection_sound_clip, Camera.main.transform.position);
            Debug.Log("Rupees: " + rupees);
        }
        else if (other.CompareTag("heart"))
        {
            HasHealth health = GetComponent<HasHealth>();
            if (health != null)
            {
                health.AlterHealth(1);
            }
            Destroy(other.gameObject);
            AudioSource.PlayClipAtPoint(heart_collection_sound_clip, Camera.main.transform.position);
        }
        else if (other.CompareTag("bomb"))
        {
            bombs += 4;
            Destroy(other.gameObject);
            Debug.Log("bomb : " + bombs);
            if (weaponHandler != null && bombWeapon != null)
            {
                weaponHandler.UnlockSecondary(bombWeapon);
            }
        }
        else if (other.CompareTag("boomerang"))
        {
            Destroy(other.gameObject);

            if (weaponHandler == null) { Debug.LogError("weaponHandler NULL"); return; }
            if (boomerangWeapon == null) { Debug.LogError("boomerangWeapon NOT ASSIGNED"); return; }

            weaponHandler.UnlockSecondary(boomerangWeapon);
            Debug.Log($"Unlocked {boomerangWeapon.weaponName}");
        }
        else if (other.CompareTag("bowPickup"))
        {
            Destroy(other.gameObject);

            if (weaponHandler == null) { Debug.LogError("weaponHandler NULL"); return; }
            if (bowWeapon == null) { Debug.LogError("bowWeapon NOT ASSIGNED"); return; }

            weaponHandler.UnlockSecondary(bowWeapon);
            Debug.Log($"Unlocked {bowWeapon.weaponName}");
        }
        else if (other.CompareTag("key"))
        {
            keys++;
            Destroy(other.gameObject);
            Debug.Log("keys : " + keys);
        }
    }

    public int GetRupees()
    {
        return rupees;
    }

    public bool SpendRupee()
    {
        if (rupees <= 0)
        {
            return false;
        }
        rupees--;
        return true;
    }

    public bool TrySpend(AmmoType type)
    {
        switch (type)
        {
            case AmmoType.Rupee:
                return SpendRupee();
            case AmmoType.Bomb:
                if (bombs <= 0) return false;
                bombs--;
                return true;
        }
        return true;
    }

    public int GetBombs()
    {
        return bombs;
    }

    public int GetKeys()
    {
        return keys;
    }

    public void MaxItems()
    {
        rupees = 1000;
        bombs = 1000;
        keys = 1000;
    }

    public bool UseKey()
    {
        if (keys == 0)
        {
            return false;
        }
        keys--;
        return true;
    }
}