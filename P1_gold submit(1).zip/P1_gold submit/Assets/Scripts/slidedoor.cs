using UnityEngine;

public class slidedoor : MonoBehaviour
{
    static public bool playerEntered = false;
    void OnTriggerEnter(Collider other)
    {
        if (gameObject.CompareTag("slideDoor") && other.CompareTag("Player"))
        {
            playerEntered = true;
        }
    }

}
