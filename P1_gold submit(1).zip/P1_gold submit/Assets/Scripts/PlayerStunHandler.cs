using System.Collections;
using UnityEngine;

public class PlayerStunHandler : MonoBehaviour
{
    public float flashTransition = 0.08f;
    public float flashDuration = 3f;
    public float invincibilityAfterStun = 0.3f; 
    private ArrowKeyMovement movement;
    private Rigidbody rb;
    SpriteRenderer sprite;
    
    public bool isStunned { get; private set; } // other scripts can check this
    public bool isInvincible { get; private set; }

    void Awake()
    {
        movement = GetComponent<ArrowKeyMovement>();
        rb = GetComponent<Rigidbody>();
        sprite = GetComponent<SpriteRenderer>();
    }

    public void ApplyKnockback(Vector2 force, float duration)
    {
         if (HasInventory.god_mode)
        {
            return; // currently immune — ignore this knockback entirely
        }
        if (isInvincible)
        {
            return;
        }
        StopAllCoroutines(); // cancel any in-progress stun, start fresh
        StartCoroutine(KnockbackStun(force, duration));
        StartCoroutine(Flash());
    }

    IEnumerator KnockbackStun(Vector2 force, float duration)
    {
        isStunned = true;
        isInvincible = true;
        movement.enabled = false;
        rb.linearVelocity = force;

        yield return new WaitForSeconds(duration);

        rb.linearVelocity = Vector2.zero;
        movement.enabled = true;
        isStunned = false;
        yield return new WaitForSeconds(invincibilityAfterStun);

        isInvincible = false;
    }

    IEnumerator Flash()
    {
        if(sprite == null)
        {
            yield break;
        }
        for(int i = 0; i < flashDuration; i++)
        {
            sprite.enabled = false;
            yield return new WaitForSeconds(flashTransition);
            sprite.enabled = true;
            yield return new WaitForSeconds(flashTransition);
        }
    }

}
