using System.Collections;
using UnityEngine;

public class Projectile_Enemy : MonoBehaviour
{
    public Sprite[] frames; // assign your 3 boomerang sprites in the Inspector
    public float frameInterval = 0.08f;
    public float travelSpeed = 6f;
    public float travelDistance = 4f;

    public bool hasReturned { get; private set; } = false;
    private Transform owner;
    private Vector2 direction;
    private float traveled = 0f;
    private bool returning = false;
    private Knockback knockback;
    private BoxCollider collide;

    void Awake()
    {
        knockback = GetComponent<Knockback>();
        collide = GetComponent<BoxCollider>();
    }

    public void Launch(Vector2 dir, Transform thrower)
    {
        direction = dir.normalized;
        owner = thrower;
        // StartCoroutine(FlipAnimation());
        StartCoroutine(FlyOutAndBack());
    }
    IEnumerator FlyOutAndBack()
    {
        while (!returning)
        {
            transform.position += (Vector3)direction * travelSpeed * Time.deltaTime;
            traveled += travelSpeed * Time.deltaTime;
            if (traveled >= travelDistance)
            {
                returning = true;
                knockback.enabled = false;
                //collide.isTrigger = true;
            }
            yield return null;
        }

        while (Vector3.Distance(transform.position, owner.position) > 0.1f)
        {
            Vector3 dirBack = (owner.position - transform.position).normalized;
            transform.position += dirBack * travelSpeed * Time.deltaTime;
            yield return null;
        }

        hasReturned = true;
    }

    void OnTriggerEnter(Collider collision)
    {
        if (returning)
        {
            return;
        }

        if (collision.gameObject.CompareTag("wall") || collision.gameObject.CompareTag("Player"))
        {
            returning = true;
        }
    }
}
