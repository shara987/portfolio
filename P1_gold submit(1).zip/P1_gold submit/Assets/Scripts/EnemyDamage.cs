using UnityEngine;

public class EnemyDamage : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public float damage = 1f;
    void Start()
{
    Debug.Log("EnemyDamage active on: " + gameObject.name);
}

    void OllisionEnter(Collision collision)
    {
        Debug.Log("Enemy collided with: " + collision.gameObject.name);
        HasHealth health = collision.gameObject.GetComponent<HasHealth>();
        if (health != null)
        {
            Debug.Log("Found HasHealth, dealing damage");
            health.TakeDamage(damage, transform.position);
        }
        else
        {
            Debug.Log("No HasHealth found");
        }
    }

}
