using System.Collections;
using UnityEngine;

public class EnemyStunHandler : MonoBehaviour
{
    public float flashTransition = 0.08f;
    public float flashDuration = 3f;
    public float invincibilityAfterStun = 0.3f; 
    private RandomMovementController movement;
    private Rigidbody rb;
    SpriteRenderer sprite;
    public bool isStunned { get; private set; } // other scripts can check this
    public bool isInvincible { get; private set; }
    public bool isWallmaster = false;

    void Awake()
    {
        movement = GetComponent<RandomMovementController>();
        rb = GetComponent<Rigidbody>();
        sprite = GetComponent<SpriteRenderer>();
    }

    public void ApplyKnockback(Vector2 force, float duration)
    {
        StopAllCoroutines();
        if (sprite != null) sprite.enabled = true;
        if (movement != null) movement.enabled = true;
        isStunned = false;
        isInvincible = false;

        if (!isWallmaster) StartCoroutine(KnockbackStun(force, duration));
        StartCoroutine(Flash());
    }


    IEnumerator KnockbackStun(Vector2 force, float duration)
    {
        isStunned = true;
        isInvincible = true;
        movement.enabled = false;
        rb.linearVelocity = force;

        yield return new WaitForSeconds(duration);

        rb.linearVelocity = Vector2.zero;
        movement.enabled = true;
        isStunned = false;

        yield return new WaitForSeconds(invincibilityAfterStun);

        isInvincible = false;
    }

    IEnumerator Flash()
    {
        if (sprite == null) yield break;
        try
        {
            for (int i = 0; i < flashDuration; i++)
            {
                sprite.enabled = false;
                yield return new WaitForSeconds(flashTransition);
                sprite.enabled = true;
                yield return new WaitForSeconds(flashTransition);
            }
        }
        finally
        {
            sprite.enabled = true;   // runs even when StopAllCoroutines kills us
        }
    }
}
